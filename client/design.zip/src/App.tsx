import { useState, useEffect } from 'react';
import { MainMenu } from './components/MainMenu';
import { GameRoom } from './components/GameRoom';
import { AvatarConfig } from './types';
import { Sparkles, Star, Award } from 'lucide-react';

export default function App() {
  const [screen, setScreen] = useState<'menu' | 'game'>('menu');
  const [playerName, setPlayerName] = useState<string>('');
  const [avatarConfig, setAvatarConfig] = useState<AvatarConfig | null>(null);
  const [isPracticeMode, setIsPracticeMode] = useState<boolean>(false);

  // Statistics trackers
  const [currentStreak, setCurrentStreak] = useState<number>(3);
  const [currentHighScore, setCurrentHighScore] = useState<number>(1250);
  const [recentScoreNotification, setRecentScoreNotification] = useState<number | null>(null);

  useEffect(() => {
    // Load persisted milestones
    const savedHighScore = localStorage.getItem('scribble_high_score');
    const savedStreak = localStorage.getItem('scribble_user_streak');

    if (savedHighScore) {
      setCurrentHighScore(parseInt(savedHighScore));
    }
    if (savedStreak) {
      setCurrentStreak(parseInt(savedStreak));
    } else {
      localStorage.setItem('scribble_user_streak', '3');
    }
  }, []);

  const handleStartGame = (name: string, avatar: AvatarConfig, isPractice: boolean) => {
    setPlayerName(name);
    setAvatarConfig(avatar);
    setIsPracticeMode(isPractice);
    setScreen('game');
  };

  const handleReturnToMenu = (finalScore?: number) => {
    setScreen('menu');
    if (finalScore !== undefined) {
      setRecentScoreNotification(finalScore);

      // check if beat highscore
      if (finalScore > currentHighScore) {
        setCurrentHighScore(finalScore);
        localStorage.setItem('scribble_high_score', finalScore.toString());
      }

      // Increment daily streak on successful completion of a game
      const newStreak = currentStreak + 1;
      setCurrentStreak(newStreak);
      localStorage.setItem('scribble_user_streak', newStreak.toString());

      // Auto clear notification banner after some seconds
      setTimeout(() => {
        setRecentScoreNotification(null);
      }, 7000);
    }
  };

  return (
    <div className="min-h-screen bg-[#060A13] text-slate-100 flex flex-col justify-between relative overflow-hidden selection:bg-indigo-500/30">
      
      {/* Decorative ambient blurred layout orbs */}
      <div className="absolute top-[-10%] left-[-10%] w-[50vw] h-[50vw] bg-indigo-900/10 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[50vw] h-[50vw] bg-purple-900/10 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute top-[40%] left-[35%] w-[30vw] h-[30vw] bg-pink-900/5 rounded-full blur-[100px] pointer-events-none" />

      {/* Main Container viewport */}
      <main className="flex-1 w-full relative z-10 flex flex-col justify-center py-4">
        
        {/* Recent Game Scores Break Notice */}
        {recentScoreNotification !== null && (
          <div className="max-w-xl mx-auto w-full px-4 mb-4 animate-bounce">
            <div className="bg-gradient-to-r from-emerald-550 to-teal-600 border border-emerald-500 text-white p-4 rounded-2xl shadow-xl flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-white/10 rounded-xl">
                  <Award className="w-5 h-5 text-yellow-300" />
                </div>
                <div>
                  <h4 className="font-extrabold text-xs uppercase tracking-wider text-emerald-100 leading-none">Game Round Achievements Saved</h4>
                  <p className="text-sm font-bold mt-1">
                    Outstanding! You gained <span className="font-mono text-yellow-300">{recentScoreNotification} pts</span>. Daily Streak boosted! ⚡
                  </p>
                </div>
              </div>
              <button 
                onClick={() => setRecentScoreNotification(null)}
                className="text-xs font-semibold text-emerald-250 hover:text-white px-2 cursor-pointer"
              >
                Dismiss
              </button>
            </div>
          </div>
        )}

        {screen === 'menu' ? (
          <MainMenu onStartGame={handleStartGame} />
        ) : (
          <GameRoom
            playerName={playerName}
            avatarConfig={avatarConfig!}
            isPracticeMode={isPracticeMode}
            onReturnToMenu={handleReturnToMenu}
          />
        )}
      </main>

      {/* Global Minimalistic Footer Branding */}
      <footer className="w-full text-center py-6 text-[11px] text-slate-600 border-t border-slate-900 z-10 select-none flex flex-col sm:flex-row justify-center items-center gap-2">
        <div className="flex items-center gap-1.5 justify-center">
          <Star className="w-3.5 h-3.5 text-yellow-600 fill-yellow-600/10" />
          <span>Skribble Studio Arena • Crafted for Professional UI/UX Matchmaking</span>
        </div>
        <span className="hidden sm:inline text-slate-800">•</span>
        <div>Secure client sandbox sessions • Persistent LocalStorage</div>
      </footer>

    </div>
  );
}
