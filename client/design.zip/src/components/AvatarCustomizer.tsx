import React from 'react';
import { AvatarConfig } from '../types';
import { Sparkles, Shuffle, Check } from 'lucide-react';

export const AVATAR_BG_COLORS = [
  '#F87171', '#FB923C', '#FBBF24', '#34D399', 
  '#60A5FA', '#818CF8', '#A78BFA', '#F472B6', 
  '#06B6D4', '#65A30D', '#0F172A', '#475569'
];

interface AvatarSVGProps {
  config: AvatarConfig;
  className?: string;
  size?: number;
}

export const AvatarSVG: React.FC<AvatarSVGProps> = ({ config, className = "w-24 h-24", size = 96 }) => {
  const { bgColor, eyes, mouth, face, accessory } = config;

  return (
    <svg 
      viewBox="0 0 100 100" 
      width={size} 
      height={size} 
      className={`rounded-2xl transition-all duration-300 shadow-md ${className}`}
      style={{ backgroundColor: bgColor }}
    >
      {/* Background radial shine */}
      <circle cx="50" cy="50" r="45" fill="white" fillOpacity="0.08" />

      {/* Ears/Side Hair/Head Additions */}
      {face === 5 && (
        <g stroke="#000" strokeWidth="3" fill="#FFF">
          {/* Bunny Ears */}
          <path d="M 30,30 C 20,5 20,5 33,26" fill={bgColor} />
          <path d="M 70,30 C 80,5 80,5 67,26" fill={bgColor} stroke="#000" />
          <path d="M 32,28 C 25,10 25,10 33,25" fill="#F472B6" opacity="0.6" />
          <path d="M 68,28 C 75,10 75,10 67,25" fill="#F472B6" opacity="0.6" />
        </g>
      )}

      {/* Main Face Container */}
      <circle cx="50" cy="55" r="30" fill="#FFDBAC" stroke="#2D3748" strokeWidth="3" />

      {/* Hair (Face configuration) */}
      {face === 1 && (
        // Spiky Hair
        <path d="M 20,53 C 18,30 25,18 50,18 C 75,18 82,30 80,53 C 78,51 72,40 65,42 C 55,44 50,30 45,40 C 35,35 25,44 20,53 Z" fill="#4B5563" stroke="#2D3748" strokeWidth="2.5" />
      )}
      {face === 2 && (
        // Double Buns
        <g fill="#B45309" stroke="#2D3748" strokeWidth="2">
          <circle cx="20" cy="35" r="12" />
          <circle cx="80" cy="35" r="12" />
          {/* Cover fringe */}
          <path d="M 20,55 C 18,40 30,30 50,30 C 70,30 82,40 80,55" fill="none" strokeWidth="3" />
        </g>
      )}
      {face === 3 && (
        // Curly/Afro
        <g fill="#1F2937" stroke="#000" strokeWidth="2">
          <circle cx="30" cy="35" r="10" />
          <circle cx="42" cy="30" r="11" />
          <circle cx="58" cy="30" r="11" />
          <circle cx="70" cy="35" r="10" />
          <circle cx="20" cy="45" r="9" />
          <circle cx="80" cy="45" r="9" />
        </g>
      )}
      {face === 4 && (
        // Red Cap Forward
        <g>
          <path d="M 22,40 C 32,22 68,22 78,40" fill="#EF4444" stroke="#2D3748" strokeWidth="3" />
          <path d="M 35,32 L 85,25 L 82,35 L 45,35 Z" fill="#DC2626" stroke="#2D3748" strokeWidth="2.5" />
        </g>
      )}

      {/* Eyes Layer */}
      <g stroke="#2D3748" strokeWidth="3" fill="none" strokeLinecap="round">
        {eyes === 0 && (
          // Regular circles
          <>
            <circle cx="40" cy="55" r="3.5" fill="#2D3748" />
            <circle cx="60" cy="55" r="3.5" fill="#2D3748" />
          </>
        )}
        {eyes === 1 && (
          // Happy Arches
          <>
            <path d="M 34,57 Q 40,50 46,57" />
            <path d="M 54,57 Q 60,50 66,57" />
          </>
        )}
        {eyes === 2 && (
          // Cool sunglasses
          <>
            <path d="M 30,52 L 48,52 L 44,61 L 32,61 Z" fill="#111827" strokeWidth="2" />
            <path d="M 52,52 L 70,52 L 68,61 L 56,61 Z" fill="#111827" strokeWidth="2" />
            <line x1="48" y1="55" x2="52" y2="55" />
          </>
        )}
        {eyes === 3 && (
          // Wink
          <>
            <path d="M 34,57 Q 40,50 46,57" />
            <circle cx="60" cy="55" r="3" fill="#2D3748" />
          </>
        )}
        {eyes === 4 && (
          // Anime / Sparkle eyes
          <>
            <circle cx="40" cy="55" r="5" fill="#2D3748" stroke="none" />
            <circle cx="60" cy="55" r="5" fill="#2D3748" stroke="none" />
            <circle cx="38" cy="53" r="1.5" fill="#FFF" stroke="none" />
            <circle cx="58" cy="53" r="1.5" fill="#FFF" stroke="none" />
            <circle cx="42" cy="57" r="0.8" fill="#FFF" stroke="none" />
            <circle cx="62" cy="57" r="0.8" fill="#FFF" stroke="none" />
          </>
        )}
        {eyes === 5 && (
          // Sleepy / Bored straight lines
          <>
            <line x1="34" y1="56" x2="46" y2="56" />
            <line x1="54" y1="56" x2="66" y2="56" />
          </>
        )}
      </g>

      {/* Mouth Layer */}
      <g stroke="#2D3748" strokeWidth="3" fill="none" strokeLinecap="round">
        {mouth === 0 && (
          // Happy Smile
          <path d="M 36,66 Q 50,77 64,66" />
        )}
        {mouth === 1 && (
          // Big open surprise/joy
          <path d="M 38,65 Q 50,82 62,65 Z" fill="#EF4444" strokeWidth="3" />
        )}
        {mouth === 2 && (
          // Cute kiss/whistle
          <circle cx="50" cy="68" r="4" fill="#F472B6" />
        )}
        {mouth === 3 && (
          // Devastated/smirking squiggle
          <path d="M 38,68 Q 44,64 50,68 T 62,68" />
        )}
        {mouth === 4 && (
          // Tongue Out
          <>
            <path d="M 40,66 L 60,66" />
            <path d="M 46,66 Q 50,76 54,66" fill="#F472B6" />
          </>
        )}
        {mouth === 5 && (
          // Neutral line
          <line x1="42" y1="68" x2="58" y2="68" />
        )}
      </g>

      {/* Accessories Layer */}
      {accessory === 1 && (
        // Round Glasses
        <g stroke="#FBBF24" strokeWidth="2.5" fill="none">
          <circle cx="40" cy="55" r="8" />
          <circle cx="60" cy="55" r="8" />
          <line x1="48" y1="55" x2="52" y2="55" />
          <line x1="28" y1="55" x2="32" y2="55" />
          <line x1="68" y1="55" x2="72" y2="55" />
        </g>
      )}
      {accessory === 2 && (
        // Cheeks Blushing
        <g opacity="0.6">
          <ellipse cx="32" cy="62" rx="4" ry="2" fill="#F472B6" stroke="none" />
          <ellipse cx="68" cy="62" rx="4" ry="2" fill="#F472B6" stroke="none" />
        </g>
      )}
      {accessory === 3 && (
        // Gaming Headset
        <g>
          <path d="M 23,55 C 23,26 77,26 77,55" fill="none" stroke="#4F46E5" strokeWidth="5.5" strokeLinecap="round" />
          <rect x="17" y="50" width="8" height="15" rx="3" fill="#312E81" stroke="#4F46E5" strokeWidth="2" />
          <rect x="75" y="50" width="8" height="15" rx="3" fill="#312E81" stroke="#4F46E5" strokeWidth="2" />
          {/* Micro boom */}
          <path d="M 23,60 Q 30,70 38,68" fill="none" stroke="#4F46E5" strokeWidth="2" />
        </g>
      )}
      {accessory === 4 && (
        // Golden Crown
        <polygon 
          points="32,32 38,20 50,28 62,20 68,32" 
          fill="#F59E0B" 
          stroke="#B45309" 
          strokeWidth="2" 
        />
      )}
    </svg>
  );
};

interface AvatarCustomizerProps {
  config: AvatarConfig;
  onChange: (newConfig: AvatarConfig) => void;
}

export const generateRandomAvatar = (): AvatarConfig => {
  return {
    bgColor: AVATAR_BG_COLORS[Math.floor(Math.random() * AVATAR_BG_COLORS.length)],
    eyes: Math.floor(Math.random() * 6),
    mouth: Math.floor(Math.random() * 6),
    face: Math.floor(Math.random() * 6),
    accessory: Math.floor(Math.random() * 5)
  };
};

export const AvatarCustomizer: React.FC<AvatarCustomizerProps> = ({ config, onChange }) => {
  const handleRandomize = () => {
    onChange(generateRandomAvatar());
  };

  const updateProp = (key: keyof AvatarConfig, val: any) => {
    onChange({ ...config, [key]: val });
  };

  return (
    <div className="bg-slate-800/80 backdrop-blur-md rounded-2xl p-6 border border-slate-700 shadow-xl flex flex-col md:flex-row gap-8 items-center max-w-2xl w-full">
      {/* Live Preview Column */}
      <div className="flex flex-col items-center gap-4 min-w-[200px]">
        <div className="p-3 bg-slate-900 rounded-3xl border border-slate-700/80 shadow-inner group relative overflow-hidden">
          <AvatarSVG config={config} size={150} className="w-40 h-40 transform group-hover:scale-105 transition-transform" />
          <div className="absolute right-2 top-2 bg-indigo-500/95 text-white p-1 rounded-full text-xs shadow-md animate-bounce">
            <Sparkles className="w-4 h-4" />
          </div>
        </div>
        <button
          onClick={handleRandomize}
          className="flex items-center gap-2 px-5 py-2.5 bg-indigo-800 hover:bg-indigo-700 text-indigo-100 rounded-xl transition font-medium text-sm border border-indigo-600/50 shadow shadow-indigo-900/50"
        >
          <Shuffle className="w-4 h-4 text-indigo-400" />
          Randomize Style
        </button>
      </div>

      {/* Options columns */}
      <div className="flex-1 w-full space-y-4">
        {/* Color Palette Choice */}
        <div>
          <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 block mb-2">Background Color</label>
          <div className="flex flex-wrap gap-2">
            {AVATAR_BG_COLORS.map(color => (
              <button
                key={color}
                onClick={() => updateProp('bgColor', color)}
                className="w-8 h-8 rounded-full border-2 transition-transform duration-200 hover:scale-110 flex items-center justify-center cursor-pointer"
                style={{ 
                  backgroundColor: color,
                  borderColor: config.bgColor === color ? '#FFFFFF' : 'transparent' 
                }}
              >
                {config.bgColor === color && <Check className="w-4 h-4 text-white drop-shadow" />}
              </button>
            ))}
          </div>
        </div>

        {/* Sliders or Tab selects for Face, Eyes, Mouth, Acc */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 block mb-1.5">Expressions (Eyes)</label>
            <div className="flex gap-1.5 bg-slate-950 p-1.5 rounded-lg border border-slate-800 overflow-x-auto">
              {[0, 1, 2, 3, 4, 5].map(styleIdx => (
                <button
                  key={styleIdx}
                  onClick={() => updateProp('eyes', styleIdx)}
                  className={`px-3 py-1 text-sm rounded-md transition font-mono ${
                    config.eyes === styleIdx 
                      ? 'bg-indigo-600 text-white font-bold' 
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                  }`}
                >
                  #{styleIdx}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 block mb-1.5">Mouth & Emotion</label>
            <div className="flex gap-1.5 bg-slate-950 p-1.5 rounded-lg border border-slate-800 overflow-x-auto">
              {[0, 1, 2, 3, 4, 5].map(styleIdx => (
                <button
                  key={styleIdx}
                  onClick={() => updateProp('mouth', styleIdx)}
                  className={`px-3 py-1 text-sm rounded-md transition font-mono ${
                    config.mouth === styleIdx 
                      ? 'bg-indigo-600 text-white font-bold' 
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                  }`}
                >
                  #{styleIdx}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 block mb-1.5">Hair & Head</label>
            <div className="flex gap-1.5 bg-slate-950 p-1.5 rounded-lg border border-slate-800 overflow-x-auto">
              {[0, 1, 2, 3, 4, 5].map(styleIdx => (
                <button
                  key={styleIdx}
                  onClick={() => updateProp('face', styleIdx)}
                  className={`px-3 py-1 text-sm rounded-md transition font-mono ${
                    config.face === styleIdx 
                      ? 'bg-indigo-600 text-white font-bold' 
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                  }`}
                >
                  #{styleIdx}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 block mb-1.5">Extra Accessories</label>
            <div className="flex gap-1.5 bg-slate-950 p-1.5 rounded-lg border border-slate-800 overflow-x-auto">
              {[0, 1, 2, 3, 4].map(styleIdx => (
                <button
                  key={styleIdx}
                  onClick={() => updateProp('accessory', styleIdx)}
                  className={`px-3 py-1 text-sm rounded-md transition font-mono ${
                    config.accessory === styleIdx 
                      ? 'bg-indigo-600 text-white font-bold' 
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                  }`}
                >
                  #{styleIdx === 0 ? 'None' : styleIdx}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
