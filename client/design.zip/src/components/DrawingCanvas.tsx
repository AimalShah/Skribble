import React, { useRef, useState, useEffect, useCallback } from 'react';
import { Undo2, Redo2, Trash2, Paintbrush, Eraser, PaintBucket, CircleDot, Eye } from 'lucide-react';
import { DrawingStroke, DrawingPoint } from '../types';

interface DrawingCanvasProps {
  isDrawingActive: boolean; // if false, the user can only view (guesser mode)
  strokes: DrawingStroke[];
  setStrokes: React.Dispatch<React.SetStateAction<DrawingStroke[]>>;
  strokeColor: string;
  setStrokeColor: (color: string) => void;
  botPathIndex?: string[]; // path commands if bot is drawing
}

const DEFAULT_COLORS = [
  '#000000', '#4B5563', '#EF4444', '#F97316', '#F59E0B', '#10B981', 
  '#06B6D4', '#3B82F6', '#6366F1', '#8B5CF6', '#EC4899', '#F43F5E',
  '#FFFFFF', '#9CA3AF', '#FECACA', '#FED7AA', '#FEF3C7', '#A7F3D0', 
  '#CFFAFE', '#DBEAFE', '#E0E7FF', '#EDE9FE', '#FCE7F3', '#FFE4E6'
];

export const DrawingCanvas: React.FC<DrawingCanvasProps> = ({
  isDrawingActive,
  strokes,
  setStrokes,
  strokeColor,
  setStrokeColor,
  botPathIndex
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [lineWidth, setLineWidth] = useState<number>(5);
  const [drawMode, setDrawMode] = useState<'draw' | 'erase' | 'fill'>('draw');
  const [undoStack, setUndoStack] = useState<DrawingStroke[][]>([]);
  const isDrawingNow = useRef<boolean>(false);
  const currentPoints = useRef<DrawingPoint[]>([]);

  // Local track of bot drawing timers
  const [botDrawingStep, setBotDrawingStep] = useState<number>(0);

  // Redraw all strokes whenever strokes array changes
  const redrawCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Draw strokes
    strokes.forEach(stroke => {
      if (stroke.points.length === 0) return;
      ctx.beginPath();
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.lineWidth = stroke.lineWidth;
      ctx.strokeStyle = stroke.mode === 'erase' ? '#FFFFFF' : stroke.color;

      ctx.moveTo(stroke.points[0].x, stroke.points[0].y);
      for (let i = 1; i < stroke.points.length; i++) {
        ctx.lineTo(stroke.points[i].x, stroke.points[i].y);
      }
      ctx.stroke();
    });
  }, [strokes]);

  // Handle canvas initialization and auto-resizing
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const fitCanvas = () => {
      // Keep internally constant 600x450 resolution to make coordinate ratios constant across devices,
      // and let CSS handle scale.
      canvas.width = 600;
      canvas.height = 420;
      redrawCanvas();
    };

    fitCanvas();
    window.addEventListener('resize', fitCanvas);
    return () => window.removeEventListener('resize', fitCanvas);
  }, [redrawCanvas]);

  useEffect(() => {
    redrawCanvas();
  }, [strokes, redrawCanvas]);

  // Execute bot automated drawing
  useEffect(() => {
    if (!botPathIndex || botPathIndex.length === 0 || isDrawingActive) {
      setBotDrawingStep(0);
      return;
    }

    // Set canvas blank first
    setStrokes([]);
    setBotDrawingStep(0);

    let currentStep = 0;
    const interval = setInterval(() => {
      if (currentStep >= botPathIndex.length) {
        clearInterval(interval);
        return;
      }

      const cmd = botPathIndex[currentStep];
      const parts = cmd.split(':');
      const action = parts[0];

      if (action === 'line') {
        const x1 = parseFloat(parts[1]) * 1.5;
        const y1 = parseFloat(parts[2]) * 1.5;
        const x2 = parseFloat(parts[3]) * 1.5;
        const y2 = parseFloat(parts[4]) * 1.5;

        // Add a line stroke
        setStrokes(prev => [
          ...prev,
          {
            points: [{ x: x1, y: y1 }, { x: x2, y: y2 }],
            color: '#1E293B',
            lineWidth: 5,
            mode: 'draw'
          }
        ]);
      } else if (action === 'rect') {
        const x = parseFloat(parts[1]) * 1.5;
        const y = parseFloat(parts[2]) * 1.5;
        const w = parseFloat(parts[3]) * 1.5;
        const h = parseFloat(parts[4]) * 1.5;

        setStrokes(prev => [
          ...prev,
          {
            points: [
              { x, y },
              { x: x + w, y },
              { x: x + w, y: y + h },
              { x, y: y + h },
              { x, y }
            ],
            color: '#1E293B',
            lineWidth: 5,
            mode: 'draw'
          }
        ]);
      } else if (action === 'circle') {
        const cx = parseFloat(parts[1]) * 1.5;
        const cy = parseFloat(parts[2]) * 1.5;
        const r = parseFloat(parts[3]) * 1.5;
        const style = parts[4] || 'stroke';

        const points: DrawingPoint[] = [];
        const steps = 30;
        for (let idx = 0; idx <= steps; idx++) {
          const theta = (idx / steps) * Math.PI * 2;
          points.push({
            x: cx + Math.cos(theta) * r,
            y: cy + Math.sin(theta) * r
          });
        }

        let circleColor = '#1E293B';
        let brushSize = 5;
        if (style.includes('green')) circleColor = '#10B981';
        if (style.includes('red')) circleColor = '#EF4444';
        if (style.includes('yellow')) circleColor = '#FBBF24';

        setStrokes(prev => [
          ...prev,
          {
            points,
            color: circleColor,
            lineWidth: brushSize,
            mode: 'draw'
          }
        ]);
      }

      currentStep++;
      setBotDrawingStep(currentStep);
    }, 400);

    return () => clearInterval(interval);
  }, [botPathIndex, isDrawingActive, setStrokes]);

  const getCoordinates = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>): DrawingPoint | null => {
    const canvas = canvasRef.current;
    if (!canvas) return null;

    const rect = canvas.getBoundingClientRect();
    let clientX = 0;
    let clientY = 0;

    if ('touches' in e) {
      if (e.touches.length === 0) return null;
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else {
      clientX = e.clientX;
      clientY = e.clientY;
    }

    // Scale back to 600x420 coordinates regardless of bounding client rect
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;

    return {
      x: (clientX - rect.left) * scaleX,
      y: (clientY - rect.top) * scaleY
    };
  };

  const handleStartDraw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawingActive) return;
    const coords = getCoordinates(e);
    if (!coords) return;

    if (drawMode === 'fill') {
      executeBucketFill(coords);
      return;
    }

    isDrawingNow.current = true;
    currentPoints.current = [coords];

    setStrokes(prev => [
      ...prev,
      {
        points: [coords],
        color: strokeColor,
        lineWidth: lineWidth,
        mode: drawMode === 'erase' ? 'erase' : 'draw'
      }
    ]);
  };

  const handleDrawMove = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawingActive || !isDrawingNow.current) return;
    const coords = getCoordinates(e);
    if (!coords) return;

    currentPoints.current.push(coords);

    setStrokes(prev => {
      const copy = [...prev];
      if (copy.length > 0) {
        copy[copy.length - 1] = {
          ...copy[copy.length - 1],
          points: [...currentPoints.current]
        };
      }
      return copy;
    });
  };

  const handleEndDraw = () => {
    if (!isDrawingActive || !isDrawingNow.current) return;
    isDrawingNow.current = false;
    currentPoints.current = [];
    // Reset undo history
    setUndoStack([]);
  };

  const executeBucketFill = (point: DrawingPoint) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Convert click coordinates to rounded integers
    const startX = Math.round(point.x);
    const startY = Math.round(point.y);

    const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const data = imgData.data;

    const targetColor = getPixelColor(data, startX, startY, canvas.width);
    const fillHexColor = strokeColor;
    const fillRgb = hexToRgb(fillHexColor);

    if (!fillRgb) return;

    // If already color, do nothing
    if (colorMatch(targetColor, fillRgb)) return;

    const queue: [number, number][] = [[startX, startY]];
    const visited = new Uint8Array(canvas.width * canvas.height);

    while (queue.length > 0) {
      const curr = queue.shift()!;
      const x = curr[0];
      const y = curr[1];
      const idx = y * canvas.width + x;

      if (x < 0 || x >= canvas.width || y < 0 || y >= canvas.height || visited[idx]) continue;
      visited[idx] = 1;

      const currColor = getPixelColor(data, x, y, canvas.width);
      if (colorMatch(currColor, targetColor)) {
        setPixelColor(data, x, y, fillRgb, canvas.width);

        queue.push([x + 1, y]);
        queue.push([x - 1, y]);
        queue.push([x, y + 1]);
        queue.push([x, y - 1]);
      }
    }

    ctx.putImageData(imgData, 0, 0);

    // Since imageData is manual canvas pixels, to keep syncing strokes clean, 
    // let's add a full fill effect as a white or specified cover in strokes,
    // or keep strokes backed up. Let's do a trick: we add this as a solid rectangle-path stroke to model.
    setStrokes(prev => [
      ...prev,
      {
        points: [
          { x: 0, y: 0 },
          { x: canvas.width, y: 0 },
          { x: canvas.width, y: canvas.height },
          { x: 0, y: canvas.height },
          { x: 0, y: 0 }
        ],
        color: fillHexColor,
        lineWidth: 999, // ultra thick to cover everything!
        mode: 'draw'
      }
    ]);
  };

  const getPixelColor = (data: Uint8ClampedArray, x: number, y: number, width: number) => {
    const idx = (y * width + x) * 4;
    return {
      r: data[idx],
      g: data[idx + 1],
      b: data[idx + 2],
      a: data[idx + 3]
    };
  };

  const setPixelColor = (data: Uint8ClampedArray, x: number, y: number, fillRgb: { r: number, g: number, b: number }, width: number) => {
    const idx = (y * width + x) * 4;
    data[idx] = fillRgb.r;
    data[idx + 1] = fillRgb.g;
    data[idx + 2] = fillRgb.b;
    data[idx + 3] = 255;
  };

  const colorMatch = (c1: { r: number, g: number, b: number, a: number }, c2: { r: number, g: number, b: number }) => {
    const delta = 32; // tolerance
    return Math.abs(c1.r - c2.r) < delta && 
           Math.abs(c1.g - c2.g) < delta && 
           Math.abs(c1.b - c2.b) < delta;
  };

  const hexToRgb = (hex: string) => {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
      r: parseInt(result[1], 16),
      g: parseInt(result[2], 16),
      b: parseInt(result[3], 16)
    } : null;
  };

  const handleUndo = () => {
    if (strokes.length === 0) return;
    const current = [...strokes];
    const undone = current.pop()!;
    setUndoStack(prev => [...prev, current]);
    setStrokes(current);
  };

  const handleRedo = () => {
    if (undoStack.length === 0) return;
    const copy = [...undoStack];
    const redoStrokes = copy.shift()!;
    setUndoStack(copy);
    setStrokes(redoStrokes);
  };

  const handleClear = () => {
    if (strokes.length === 0) return;
    setUndoStack(prev => [...prev, strokes]);
    setStrokes([]);
  };

  return (
    <div ref={containerRef} className="flex flex-col flex-1 min-w-0 bg-white rounded-2xl shadow-lg border border-slate-200 overflow-hidden relative">
      
      {/* Guesser Mode Overlay Status banner */}
      {!isDrawingActive && (
        <div className="absolute top-2 left-1/2 transform -translate-x-1/2 bg-slate-900/90 backdrop-blur text-white px-4 py-1.5 rounded-full text-xs font-semibold flex items-center gap-2 z-10 shadow border border-slate-700/50">
          <Eye className="w-3.5 h-3.5 text-indigo-400 animate-pulse" />
          <span>Guesser Mode • Watch closely!</span>
        </div>
      )}

      {/* Canvas Drawing Stage */}
      <div className="relative flex-1 bg-slate-100 min-h-[250px] overflow-hidden">
        <canvas
          id="drawing_canvas_main"
          ref={canvasRef}
          onMouseDown={handleStartDraw}
          onMouseMove={handleDrawMove}
          onMouseUp={handleEndDraw}
          onMouseLeave={handleEndDraw}
          onTouchStart={handleStartDraw}
          onTouchMove={handleDrawMove}
          onTouchEnd={handleEndDraw}
          className={`w-full h-full object-contain bg-white block ${
            isDrawingActive ? 'cursor-crosshair' : 'cursor-not-allowed pointer-events-none'
          }`}
        />
      </div>

      {/* Control Tool Box - ONLY visible and active if custom drawing */}
      {isDrawingActive && (
        <div className="bg-slate-50 border-t border-slate-200 p-3 select-none">
          {/* Main brush size, modes and undo controls */}
          <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
            
            {/* Draw modes */}
            <div className="flex items-center gap-1.5 p-1 bg-slate-200/60 rounded-xl">
              <button
                onClick={() => setDrawMode('draw')}
                title="Brush tool"
                className={`p-2 rounded-lg transition-all duration-200 ${
                  drawMode === 'draw' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-600 hover:bg-slate-300/50'
                }`}
              >
                <Paintbrush className="w-4 h-4" />
              </button>
              <button
                onClick={() => setDrawMode('erase')}
                title="Eraser tool"
                className={`p-2 rounded-lg transition-all duration-200 ${
                  drawMode === 'erase' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-600 hover:bg-slate-300/50'
                }`}
              >
                <Eraser className="w-4 h-4" />
              </button>
              <button
                onClick={() => setDrawMode('fill')}
                title="Flood fill bucket"
                className={`p-2 rounded-lg transition-all duration-200 ${
                  drawMode === 'fill' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-600 hover:bg-slate-300/50'
                }`}
              >
                <PaintBucket className="w-4 h-4" />
              </button>
            </div>

            {/* Slider brush width */}
            <div className="flex items-center gap-3 bg-white border border-slate-200/80 rounded-xl px-3 py-1.5 flex-1 min-w-[150px] max-w-[240px]">
              <CircleDot className="w-4 h-4 text-slate-500 reduce-shrink" />
              <input
                type="range"
                min="2"
                max="40"
                value={lineWidth}
                onChange={e => setLineWidth(parseInt(e.target.value))}
                className="w-full accent-indigo-600 h-1 bg-slate-200 rounded-lg cursor-pointer"
              />
              <span className="text-xs font-mono font-bold text-slate-600 min-w-[20px] text-right">{lineWidth}px</span>
            </div>

            {/* Clear, undo, redo operations */}
            <div className="flex items-center gap-1">
              <button
                onClick={handleUndo}
                disabled={strokes.length === 0}
                title="Undo stroke"
                className="p-2 text-slate-600 hover:bg-slate-200 disabled:opacity-40 rounded-lg transition"
              >
                <Undo2 className="w-4.5 h-4.5" />
              </button>
              <button
                onClick={handleRedo}
                disabled={undoStack.length === 0}
                title="Redo stroke"
                className="p-2 text-slate-600 hover:bg-slate-200 disabled:opacity-40 rounded-lg transition"
              >
                <Redo2 className="w-4.5 h-4.5" />
              </button>
              <button
                onClick={handleClear}
                disabled={strokes.length === 0}
                title="Clear canvas"
                className="p-2 text-red-600 hover:bg-red-50 disabled:opacity-40 rounded-lg transition ml-1"
              >
                <Trash2 className="w-4.5 h-4.5" />
              </button>
            </div>

          </div>

          {/* Rapid Color Selections */}
          <div className="grid grid-cols-12 gap-1.5 md:gap-2">
            {DEFAULT_COLORS.map(color => (
              <button
                key={color}
                onClick={() => {
                  setStrokeColor(color);
                  if (drawMode === 'erase') setDrawMode('draw');
                }}
                className={`aspect-square rounded-lg relative cursor-pointer border shadow-sm transition-transform duration-100 hover:scale-110 flex items-center justify-center ${
                  strokeColor === color && drawMode !== 'erase'
                    ? 'border-slate-900 ring-2 ring-indigo-500 scale-105 z-10' 
                    : 'border-slate-300'
                }`}
                style={{ backgroundColor: color }}
              >
                {strokeColor === color && drawMode !== 'erase' && (
                  <div className={`w-1.5 h-1.5 rounded-full ${color === '#FFFFFF' ? 'bg-slate-900' : 'bg-white'}`} />
                )}
              </button>
            ))}
          </div>

        </div>
      )}
    </div>
  );
};
