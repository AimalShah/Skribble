import React, { useState, useEffect, useRef } from 'react';
import { Player, Message, WordItem, DrawingStroke, AvatarConfig, GameStatus } from '../types';
import { AvatarSVG, generateRandomAvatar } from './AvatarCustomizer';
import { DrawingCanvas } from './DrawingCanvas';
import { GAME_WORDS, getRandomWord, BOT_NAMES } from '../data/words';
import { Send, Clock, Volume2, VolumeX, Award, SkipForward, ArrowRight, CornerDownLeft, Sparkles, Smile } from 'lucide-react';

interface GameRoomProps {
  playerName: string;
  avatarConfig: AvatarConfig;
  isPracticeMode: boolean; // if true, solo practice sandbox with no timers or bots
  onReturnToMenu: (finalScore?: number) => void;
}

export const GameRoom: React.FC<GameRoomProps> = ({
  playerName,
  avatarConfig,
  isPracticeMode,
  onReturnToMenu
}) => {
  // Game state
  const [gameStatus, setGameStatus] = useState<GameStatus>(isPracticeMode ? 'drawing' : 'selecting_word');
  const [round, setRound] = useState<number>(1);
  const [totalRounds] = useState<number>(3);
  const [timeLeft, setTimeLeft] = useState<number>(60);
  const [players, setPlayers] = useState<Player[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [currentDrawer, setCurrentDrawer] = useState<Player | null>(null);
  const [secretWord, setSecretWord] = useState<WordItem | null>(null);
  const [wordChoices, setWordChoices] = useState<WordItem[]>([]);
  const [strokes, setStrokes] = useState<DrawingStroke[]>([]);
  const [strokeColor, setStrokeColor] = useState<string>('#000000');
  const [chatInput, setChatInput] = useState<string>('');
  const [userHasGuessedCorrectly, setUserHasGuessedCorrectly] = useState<boolean>(false);
  
  // Audio state (sound triggers via simple web audio synthesizer)
  const [volumeOn, setVolumeOn] = useState<boolean>(true);

  // References
  const chatBottomRef = useRef<HTMLDivElement | null>(null);
  const botGuessTimer = useRef<NodeJS.Timeout | null>(null);
  const countdownTimer = useRef<NodeJS.Timeout | null>(null);

  // Trigger web audio sound synthesis safely (no external assets asset dependency)
  const playSynthSound = (type: 'correct' | 'tick' | 'victory' | 'pop') => {
    if (!volumeOn) return;
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();

      osc.connect(gain);
      gain.connect(audioCtx.destination);

      if (type === 'tick') {
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(350, audioCtx.currentTime);
        gain.gain.setValueAtTime(0.04, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.1);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.1);
      } else if (type === 'correct') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(523.25, audioCtx.currentTime); // C5
        osc.frequency.setValueAtTime(659.25, audioCtx.currentTime + 0.08); // E5
        osc.frequency.setValueAtTime(783.99, audioCtx.currentTime + 0.16); // G5
        gain.gain.setValueAtTime(0.1, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.35);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.35);
      } else if (type === 'pop') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(220, audioCtx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(440, audioCtx.currentTime + 0.12);
        gain.gain.setValueAtTime(0.06, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.15);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.15);
      } else if (type === 'victory') {
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(440, audioCtx.currentTime);
        osc.frequency.setValueAtTime(554.37, audioCtx.currentTime + 0.1);
        osc.frequency.setValueAtTime(659.25, audioCtx.currentTime + 0.2);
        osc.frequency.setValueAtTime(880, audioCtx.currentTime + 0.3);
        gain.gain.setValueAtTime(0.05, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.6);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.6);
      }
    } catch {
      // Audio permission blocked or not supported
    }
  };

  // Initialize Players (User + Bots)
  useEffect(() => {
    // 1 user + 5 random bots
    const userPlayer: Player = {
      id: 'user_player',
      name: playerName,
      avatar: avatarConfig,
      score: 0,
      isDrawing: false,
      isHost: true,
      hasGuessed: false
    };

    const shuffledBotNames = [...BOT_NAMES].sort(() => 0.5 - Math.random());
    const botPlayers: Player[] = shuffledBotNames.slice(0, 4).map((name, idx) => ({
      id: `bot_player_${idx}`,
      name,
      avatar: {
        bgColor: ['#F87171', '#34D399', '#60A5FA', '#FBBF24', '#A78BFA'][idx],
        eyes: Math.floor(Math.random() * 6),
        mouth: Math.floor(Math.random() * 6),
        face: Math.floor(Math.random() * 6),
        accessory: Math.floor(Math.random() * 5)
      },
      score: 0,
      isDrawing: false,
      isHost: false,
      hasGuessed: false,
      isBot: true
    }));

    const allPlayersList = [userPlayer, ...botPlayers];
    setPlayers(allPlayersList);

    if (isPracticeMode) {
      setCurrentDrawer(userPlayer);
      setSecretWord({ word: 'Dojo Sandbox', category: 'Creative Practice', hint: 'Sketch anything!' });
      pushSystemMessage('🎨 Drawing Sandbox started. Scribble, test colors, and practice with no ticking clocks!');
    } else {
      pushSystemMessage('👋 Welcome to Skribble Studio Match Arena!');
      pushSystemMessage('🎮 Matchmaking joined. Round 1 starting now!');
      startTurnSetup(allPlayersList, 1);
    }
  }, []);

  // Scroll chat to bottom
  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Handle countdown Timer ticking
  useEffect(() => {
    if (isPracticeMode || gameStatus !== 'drawing') return;

    countdownTimer.current = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          clearInterval(countdownTimer.current!);
          handleTurnTimeOut();
          return 0;
        }
        if (prev <= 10) {
          playSynthSound('tick');
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (countdownTimer.current) clearInterval(countdownTimer.current);
    };
  }, [gameStatus, isPracticeMode, secretWord]);

  // Automated Bot actions (guessing & chatting)
  useEffect(() => {
    if (isPracticeMode || gameStatus !== 'drawing' || !secretWord) return;

    // Set recursive timer to dispatch funny bot guesses occasionally
    const scheduleNextBotAction = () => {
      const delay = Math.random() * 6000 + 4000; // between 4 and 10 seconds
      botGuessTimer.current = setTimeout(() => {
        simulateBotGuess();
        scheduleNextBotAction(); // queue next
      }, delay);
    };

    scheduleNextBotAction();

    return () => {
      if (botGuessTimer.current) clearTimeout(botGuessTimer.current);
    };
  }, [gameStatus, isPracticeMode, secretWord, players]);

  // Setup Turn: choose secret word, set drawer
  const startTurnSetup = (playersList: Player[], currentRound: number) => {
    // Decide who is drawing
    // Round 1: Bot (idx 1), Round 2: User (idx 0), Round 3: Bot (idx 2)
    let drawerIdx = 1;
    if (currentRound === 2) drawerIdx = 0;
    if (currentRound === 3) drawerIdx = 2;

    const drawer = playersList[drawerIdx] || playersList[0];
    
    // Update players state to show current drawing
    setPlayers(prev => prev.map((p, i) => ({
      ...p,
      isDrawing: p.id === drawer.id,
      hasGuessed: false
    })));

    setCurrentDrawer(drawer);
    setStrokes([]);
    setUserHasGuessedCorrectly(false);
    setTimeLeft(60);

    pushSystemMessage(`🎨 Round ${currentRound} of ${totalRounds}`);

    if (drawer.id === 'user_player') {
      // User is drawing, show word selectors
      setGameStatus('selecting_word');
      // Produce 3 random choice words
      const choices = [getRandomWord(), getRandomWord(), getRandomWord()];
      setWordChoices(choices);
      pushSystemMessage('👉 Pick a word to start drawing!');
    } else {
      // Bot is drawing
      setGameStatus('selecting_word');
      const randomWordSelected = getRandomWord();
      setSecretWord(randomWordSelected);
      
      const selectDelay = setTimeout(() => {
        setGameStatus('drawing');
        pushSystemMessage(`✏️ ${drawer.name} is choosing a word...`);
        pushSystemMessage(`🎨 ${drawer.name} has started drawing! Guess what it is!`);
        playSynthSound('pop');
      }, 2000);

      return () => clearTimeout(selectDelay);
    }
  };

  // Helper to append chat messaging
  const pushSystemMessage = (text: string, type: 'system' | 'correct' | 'close' = 'system') => {
    const newMsg: Message = {
      id: Math.random().toString(),
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      type
    };
    setMessages(prev => [...prev, newMsg]);
  };

  const pushPlayerMessage = (senderId: string, senderName: string, text: string) => {
    const newMsg: Message = {
      id: Math.random().toString(),
      senderId,
      senderName,
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      type: 'chat'
    };
    setMessages(prev => [...prev, newMsg]);
  };

  // Simulate automated Bot typing guesses
  const simulateBotGuess = () => {
    if (!secretWord) return;

    // Grab all bots that have not guessed correctly yet
    const unsolvedBots = players.filter(p => p.isBot && !p.hasGuessed && !p.isDrawing);
    if (unsolvedBots.length === 0) return;

    const selectedBot = unsolvedBots[Math.floor(Math.random() * unsolvedBots.length)];

    // Decide if bot guessing correct or type random bad guess
    const targetWordStr = secretWord.word.toLowerCase();
    
    // Percent chance of getting correct answer increases as remaining time decreases!
    const correctChance = timeLeft > 40 ? 0.22 : timeLeft > 20 ? 0.38 : 0.65;
    const isCloseChance = 0.25;

    const willBeCorrect = Math.random() < correctChance;
    const willBeClose = !willBeCorrect && Math.random() < isCloseChance;

    if (willBeCorrect) {
      // bot guesses correct word!
      markPlayerCorrect(selectedBot.id);
    } else if (willBeClose) {
      // Guess a close word (similar characters or prefix/suffix)
      const typo = targetWordStr.slice(0, -1) + 's';
      pushPlayerMessage(selectedBot.id, selectedBot.name, typo);
      pushSystemMessage(`⚠️ ${selectedBot.name} is very close!`, 'close');
      playSynthSound('pop');
    } else {
      // Pick a random funny guess
      const randomGuesses = [
        'what is that??', 'circle?', 'looks like food', 'house?', 'drawing looks amazing', 
        'tree?', 'i am confused', 'is it a line?', 'triangle', 'cloud maybe', 'car!'
      ];
      const guess = randomGuesses[Math.floor(Math.random() * randomGuesses.length)];
      pushPlayerMessage(selectedBot.id, selectedBot.name, guess);
    }
  };

  // Mark a player as having solved the drawer's word
  const markPlayerCorrect = (playerId: string) => {
    setPlayers(prev => prev.map(p => {
      if (p.id === playerId) {
        // Calculate points based on remaining time
        const pointsEarned = Math.round(timeLeft * 8 + 150);
        
        // Push notification
        if (p.id === 'user_player') {
          setUserHasGuessedCorrectly(true);
          pushSystemMessage(`🎉 You guessed the word correctly! (+${pointsEarned} pts)`, 'correct');
          playSynthSound('correct');
        } else {
          pushSystemMessage(`⭐ ${p.name} guessed the word correctly!`, 'correct');
          playSynthSound('pop');
        }

        return {
          ...p,
          hasGuessed: true,
          score: p.score + pointsEarned
        };
      }
      return p;
    }));

    // Check if everyone got it correct
    setTimeout(checkAllSolvedStatus, 500);
  };

  const checkAllSolvedStatus = () => {
    setPlayers(prev => {
      const activeGuessers = prev.filter(p => !p.isDrawing);
      const solvedGuessers = activeGuessers.filter(p => p.hasGuessed);
      
      // If everyone guessed, end round early
      if (activeGuessers.length > 0 && solvedGuessers.length === activeGuessers.length) {
        setGameStatus('round_end');
        if (countdownTimer.current) clearInterval(countdownTimer.current);
        playSynthSound('victory');
      }
      return prev;
    });
  };

  // Handle timer running out
  const handleTurnTimeOut = () => {
    setGameStatus('round_end');
  };

  // Skip / speed turn transition to next round
  const handleProceedToNextRound = () => {
    if (round < totalRounds) {
      const nextRound = round + 1;
      setRound(nextRound);
      startTurnSetup(players, nextRound);
    } else {
      // Match Finished! Wrap up scores
      setGameStatus('game_over');
      playSynthSound('victory');
    }
  };

  // Handle user typing and submitting guess
  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;

    const typedText = chatInput.trim();
    setChatInput('');

    // Check if user is the drawer (drawers shouldn't chat guess inputs to cheat!)
    if (currentDrawer?.id === 'user_player') {
      pushPlayerMessage('user_player', playerName, typedText);
      pushSystemMessage('⚠️ Drawing artists cannot leak hints inside the chat!');
      return;
    }

    // Check if user already solved it
    if (userHasGuessedCorrectly) {
      pushSystemMessage('🔇 Shh! You already guessed the word! Let others solve it.');
      return;
    }

    // Push guess to list
    pushPlayerMessage('user_player', playerName, typedText);

    if (secretWord && typedText.toLowerCase() === secretWord.word.toLowerCase()) {
      markPlayerCorrect('user_player');
    } else if (secretWord && isApproximateMatch(typedText, secretWord.word)) {
      pushSystemMessage('⚠️ You are extremely close to the secret word!', 'close');
    }
  };

  const isApproximateMatch = (str1: string, str2: string): boolean => {
    const s1 = str1.toLowerCase().trim();
    const s2 = str2.toLowerCase().trim();
    if (s1 === s2) return true;
    
    // Simple lev distance or substring check
    if (s2.includes(s1) && s1.length >= 3) return true;
    return false;
  };

  // Handle word selection from the 3 choices
  const handleSelectWord = (word: WordItem) => {
    setSecretWord(word);
    setGameStatus('drawing');
    pushSystemMessage(`🎨 You chose to draw: **${word.word.toUpperCase()}**! Get ready!`);
    playSynthSound('correct');
  };

  // Returns word hint string (e.g. C _ _ _ _) for guessers
  const getWordMask = (): string => {
    if (!secretWord) return '';
    if (currentDrawer?.id === 'user_player' || gameStatus === 'round_end' || gameStatus === 'game_over') {
      return secretWord.word;
    }

    const chars = secretWord.word.split('');
    const mask = chars.map((char, index) => {
      if (char === ' ') return ' ';
      // Reveal first or last letter occasionally based on countdown
      if (index === 0 && timeLeft <= 45) return char;
      if (index === chars.length - 1 && timeLeft <= 25) return char;
      return '_';
    });

    return mask.join(' ');
  };

  // Calculate final placement stats
  const sortedPlayers = [...players].sort((a, b) => b.score - a.score);
  const userPlacement = sortedPlayers.findIndex(p => p.id === 'user_player') + 1;
  const userScore = players.find(p => p.id === 'user_player')?.score || 0;

  return (
    <div className="max-w-7xl mx-auto w-full px-2 sm:px-4 py-4 md:py-6 flex flex-col gap-4">
      
      {/* HEADER: Timer, Category, Score stats, skipping controls with handwritten borders */}
      <div className="bg-slate-900/80 sketchy-card border-slate-700 p-4 flex flex-wrap items-center justify-between gap-4 shadow-xl select-none wobbly-glow">
        
        {/* Play-turn metadata */}
        <div className="flex items-center gap-4">
          <div className="flex items-center justify-center bg-indigo-600 font-bold text-sm md:text-md text-white w-20 md:w-24 py-2.5 sketchy-btn border-indigo-400 wobbly-glow shrink-0">
            {isPracticeMode ? 'SANDBOX' : `ROUND ${round}/${totalRounds}`}
          </div>
          <div>
            <h2 className="text-sm font-bold text-yellow-300 uppercase tracking-wider leading-none font-display">
              {currentDrawer?.id === 'user_player' ? '✏️ YOU ARE DRAWING!' : `🎨 ${currentDrawer?.name || 'Someone'} is Drawing:`}
            </h2>
            <div className="flex items-center gap-2 mt-1">
              <span className="text-2xl md:text-3xl font-bold text-white tracking-widest uppercase font-display leading-none">
                {getWordMask() || 'Selecting...'}
              </span>
              {secretWord && (
                <span className="text-xs font-bold px-2.5 py-1 rounded-lg bg-indigo-950 border border-indigo-850 text-slate-200">
                  {secretWord.category}
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Secret hint if guesser */}
        {!isPracticeMode && secretWord && currentDrawer?.id !== 'user_player' && (
          <div className="bg-slate-950/80 text-slate-300 border-2 border-dashed border-slate-750 text-xs px-4 py-2.5 rounded-xl max-w-sm hidden lg:block">
            <span className="font-bold text-yellow-400 font-display text-sm">Artist Clue:</span> {secretWord.hint}
          </div>
        )}

        {/* Dynamic Countdown clock timer badge */}
        {!isPracticeMode && (
          <div className="flex items-center gap-3">
            <div className={`flex items-center gap-2 px-5 py-2.5 font-bold text-lg sketchy-btn transition-all duration-300 ${
              timeLeft <= 10 
                ? 'bg-red-500/20 text-red-500 border-red-550 animate-pulse scale-105 wobbly-glow-red' 
                : 'bg-slate-950 text-slate-100 border-indigo-505 wobbly-glow'
            }`}>
              <Clock className={`w-5 h-5 ${timeLeft <= 10 ? 'text-red-550 animate-bounce' : 'text-indigo-400'}`} />
              <span className="text-xl font-display">{timeLeft} sec</span>
            </div>

            {/* Sound Toggle */}
            <button
              onClick={() => setVolumeOn(!volumeOn)}
              className="p-3 bg-slate-950 hover:bg-slate-800 border-2 border-slate-750 rounded-xl text-slate-400 hover:text-slate-200 transition cursor-pointer"
            >
              {volumeOn ? <Volume2 className="w-4.5 h-4.5 text-indigo-400" /> : <VolumeX className="w-4.5 h-4.5" />}
            </button>
          </div>
        )}

        {/* Solo practice leave option */}
        {isPracticeMode && (
          <button
            onClick={() => onReturnToMenu()}
            className="px-5 py-2 bg-red-600/10 hover:bg-red-600/20 border-2 border-dashed border-red-500/30 text-red-405 font-bold text-xs rounded-xl uppercase tracking-wider transition cursor-pointer font-display sketchy-btn"
          >
            Leave Dojo
          </button>
        )}
      </div>

      {/* CORE GAME LAYOUT: 3 responsive columns */}
      <div className="grid lg:grid-cols-12 gap-4 items-stretch">
        
        {/* COLUMN 1 (Lg: 3): Scoreboard Players list */}
        <div className="lg:col-span-3 bg-slate-900/80 border-slate-700 sketchy-card p-4 flex flex-col gap-3 shadow-lg wobbly-glow-red">
          <div className="text-sm font-bold uppercase tracking-wider text-yellow-300 border-b-2 border-dashed border-slate-800 pb-2 mb-1 flex items-center justify-between font-display">
            <span>Scoreboard</span>
            {!isPracticeMode && <span className="text-[11px] text-indigo-300 font-display bg-indigo-950 border border-indigo-800 px-2 py-0.5 rounded-md">{players.length} Artists</span>}
          </div>

          <div className="flex flex-col gap-2.5 flex-1 overflow-y-auto max-h-[140px] lg:max-h-none pr-1">
            {players.sort((a,b)=> b.score - a.score).map((player, idx) => {
              const isUser = player.id === 'user_player';
              return (
                <div 
                  key={player.id}
                  className={`flex items-center justify-between p-2.5 rounded-2xl border-2 transition-all duration-200 sketchy-card-subtle ${
                    player.hasGuessed 
                      ? 'bg-emerald-500/10 border-emerald-500/80 shadow-[4px_4px_0px_0px_rgba(16,185,129,0.3)]' 
                      : player.isDrawing 
                        ? 'bg-indigo-500/15 border-indigo-500/80 shadow-[4px_4px_0px_0px_rgba(99,102,241,0.35)]' 
                        : 'bg-slate-950/60 border-slate-800'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    {/* Rank Number */}
                    <span className="text-xs font-bold text-slate-400 w-4 text-center font-display">
                      #{idx + 1}
                    </span>

                    {/* Miniature Avatar */}
                    <div className="p-0.5 rounded-xl border-2 border-slate-750 bg-slate-950 shrink-0">
                      <AvatarSVG config={player.avatar} size={28} className="w-7 h-7" />
                    </div>

                    {/* Nickname, Tag */}
                    <div className="min-w-0">
                      <span className={`text-sm font-bold truncate block max-w-[100px] font-display ${isUser ? 'text-indigo-400 font-extrabold text-md' : 'text-slate-200'}`}>
                        {player.name} {isUser && '(You)'}
                      </span>
                      {player.isDrawing && (
                        <span className="text-[10px] text-indigo-400 font-bold block leading-none font-display">✏️ Drawing</span>
                      )}
                      {player.hasGuessed && (
                        <span className="text-[10px] text-emerald-400 font-bold block leading-none font-display">⭐ Solved!</span>
                      )}
                    </div>
                  </div>

                  {/* Score */}
                  <div className="text-right shrink-0">
                    <span className="text-md font-bold text-slate-100 font-display block leading-none">{player.score}</span>
                    <span className="text-[9px] text-slate-400 uppercase leading-none font-bold font-display">score</span>
                  </div>
                </div>
              );
            })}
          </div>

          {!isPracticeMode && (
            <div className="bg-slate-950/90 rounded-2xl p-3.5 border-2 border-dashed border-slate-800 hidden lg:block">
              <span className="text-[11px] font-bold text-yellow-400 uppercase tracking-wider block mb-1 font-display">HELPFUL DOJO TIP</span>
              <p className="text-xs text-slate-400 leading-normal font-sans">
                Type anything that looks close inside the right hand panel check. Suffix & prefix hints will notify you if you are warm!
              </p>
            </div>
          )}
        </div>

        {/* COLUMN 2 (Lg: 6): Center Draw Dashboard Screen Canvas */}
        <div className="lg:col-span-6 flex flex-col gap-4 min-w-0">
          
          {/* Active Canvas wrapper */}
          <div className="flex-1 min-h-[350px] md:min-h-[430px] flex flex-col relative sketchy-card border-slate-700 bg-slate-950 p-2 overflow-hidden wobbly-glow">
            <DrawingCanvas
              isDrawingActive={currentDrawer?.id === 'user_player' && gameStatus === 'drawing'}
              strokes={strokes}
              setStrokes={setStrokes}
              strokeColor={strokeColor}
              setStrokeColor={setStrokeColor}
              botPathIndex={currentDrawer?.id !== 'user_player' && gameStatus === 'drawing' ? secretWord?.botPath : undefined}
            />

            {/* SELECTION OVERLAY: choose word to draw screen with playful fonts */}
            {gameStatus === 'selecting_word' && currentDrawer?.id === 'user_player' && (
              <div className="absolute inset-0 bg-slate-950/98 rounded-2xl flex flex-col items-center justify-center p-6 z-20 text-center select-none animate-fadeIn border-2 border-indigo-500">
                <div className="inline-flex items-center justify-center bg-indigo-500/15 text-indigo-300 border-2 border-dashed border-indigo-400/40 px-3.5 py-1.5 rounded-full text-xs font-bold mb-4 animate-bounce font-display">
                  <Award className="w-4 h-4 mr-1 text-yellow-300" />
                  <span>SELECT A WORD TO SKETCH</span>
                </div>
                <h3 className="text-3xl font-extrabold text-white font-display">IT'S YOUR TURN TIME!</h3>
                <p className="text-slate-350 text-sm mt-1 mb-8 max-w-sm font-sans">
                  Select one keyword. You score proportional extra points if other online painters guess accurately!
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 w-full max-w-lg">
                  {wordChoices.map(word => (
                    <button
                      key={word.word}
                      onClick={() => handleSelectWord(word)}
                      className="bg-indigo-650 hover:bg-indigo-600 text-white font-bold p-4 pb-5 rounded-2xl transition duration-200 sketchy-btn border-white/20 select-none cursor-pointer"
                    >
                      <div className="text-lg uppercase font-display select-none">{word.word}</div>
                      <div className="text-[11px] text-indigo-300 font-bold mt-1 tracking-normal font-sans capitalize">{word.category}</div>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* ROUND OVER RECAP SCREEN INTERSTITIAL */}
            {gameStatus === 'round_end' && (
              <div className="absolute inset-0 bg-slate-950/98 rounded-2xl flex flex-col items-center justify-center p-6 z-20 text-center animate-fadeIn select-none border-2 border-dashed border-yellow-400">
                <div className="text-yellow-400 font-bold text-sm bg-yellow-500/10 border-2 border-dashed border-yellow-500/40 px-4 py-1.5 rounded-full mb-4 font-display">
                  Round {round} Completed! 🔔
                </div>
                
                <h3 className="text-lg text-slate-400 font-display">The secret word was solved:</h3>
                <h2 className="text-4xl md:text-6xl font-bold uppercase text-yellow-300 tracking-wider mt-1 mb-6 font-display">
                  {secretWord?.word}
                </h2>

                <div className="w-full max-w-sm bg-slate-900 border-2 border-dashed border-slate-750 p-4 rounded-2xl mb-8">
                  <h4 className="text-xs font-bold text-slate-400 uppercase block border-b-2 border-slate-800 pb-2 mb-2 font-display">Round Scoreboard Summary</h4>
                  <div className="space-y-2">
                    {players.sort((a,b)=>b.score - a.score).slice(0, 3).map((p, idx) => (
                      <div key={p.id} className="flex items-center justify-between text-sm">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-slate-500 font-display">#{idx+1}</span>
                          <span className="font-bold text-slate-200 font-display">{p.name}</span>
                        </div>
                        <span className="font-bold text-yellow-300 font-display">{p.score} pts</span>
                      </div>
                    ))}
                  </div>
                </div>

                <button
                  onClick={handleProceedToNextRound}
                  className="flex items-center gap-2 px-6 py-3.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-sm tracking-wide transition duration-200 cursor-pointer sketchy-btn border-white/20 wobbly-glow"
                >
                  <span>{round < totalRounds ? 'PROCEED TO NEXT ROUND' : 'SEE FINAL STANDINGS'}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            )}

            {/* FINAL GAME OVER SUMMARY RECAP SCREEN */}
            {gameStatus === 'game_over' && (
              <div className="absolute inset-0 bg-slate-950/98 rounded-2xl flex flex-col items-center justify-center p-6 z-20 text-center select-none animate-fadeIn border-3 border-yellow-400">
                <div className="p-3 bg-yellow-400/10 border-2 border-yellow-450 text-yellow-350 scale-110 mb-5 animate-bounce rounded-full">
                  <Award className="w-7 h-7" />
                </div>
                
                <h2 className="text-4xl font-bold tracking-tight text-white uppercase font-display text-yellow-300">MATCH COMPLETED! 🎉</h2>
                <p className="text-slate-350 text-sm mt-1 mb-8 max-w-sm font-sans">
                  Excellent sketches! Standings calculated dynamically for this arena round:
                </p>

                {/* Final standing list */}
                <div className="grid grid-cols-3 gap-3 md:gap-5 max-w-md w-full mb-8 items-end">
                  {sortedPlayers.slice(0, 3).map((p, index) => (
                    <div 
                      key={p.id} 
                      className={`p-4 rounded-2xl border-2 text-center relative ${
                        index === 0 
                          ? 'bg-amber-500/10 border-amber-500 ring-4 ring-amber-500/10 order-2 scale-105 shadow-[4px_4px_0px_0px_rgba(245,158,11,0.3)] font-display' 
                          : index === 1 
                            ? 'bg-slate-300/10 border-slate-650 order-1 shadow-[4px_4px_0px_0px_rgba(148,163,184,0.2)] font-display' 
                            : 'bg-amber-950/10 border-amber-900 order-3 shadow-[4px_4px_0px_0px_rgba(120,53,4,0.2)] font-display'
                      }`}
                    >
                      {/* Placement Medal Badge */}
                      <span className={`absolute -top-3.5 left-1/2 transform -translate-x-1/2 text-[10px] uppercase font-bold px-3 py-1 rounded-full border-2 shadow-md ${
                        index === 0 
                          ? 'bg-yellow-400 text-yellow-950 border-yellow-300' 
                          : index === 1 
                            ? 'bg-slate-300 text-slate-900 border-slate-200' 
                            : 'bg-amber-600 text-amber-50 border-amber-500'
                      }`}>
                        {index === 0 ? '1st' : index === 1 ? '2nd' : '3rd'}
                      </span>

                      <div className="p-0.5 my-2.5 rounded-xl bg-slate-950 inline-block border border-slate-800">
                        <AvatarSVG config={p.avatar} size={48} className="w-12 h-12" />
                      </div>
                      
                      <div className="font-bold text-xs text-slate-100 truncate max-w-[80px] mx-auto font-display">{p.name}</div>
                      <div className="font-display text-sm text-yellow-300 font-bold mt-1">{p.score} pts</div>
                    </div>
                  ))}
                </div>

                <div className="flex gap-3">
                  <button
                    onClick={() => {
                      // Save score to statistics before leaving
                      const savedHighScore = parseInt(localStorage.getItem('scribble_high_score') || '0');
                      if (userScore > savedHighScore) {
                        localStorage.setItem('scribble_high_score', userScore.toString());
                      }
                      onReturnToMenu(userScore);
                    }}
                    className="px-6 py-4 bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-bold text-sm tracking-wide transition cursor-pointer sketchy-btn border-slate-950 shadow-md wobbly-glow-green"
                  >
                    RETURN TO ARENA HALL 🚪
                  </button>
                </div>
              </div>
            )}

          </div>

        </div>

        {/* COLUMN 3 (Lg: 3): Right dynamic live Chat and Guess console with scribbled outlines */}
        <div className="lg:col-span-3 bg-slate-900/80 border-slate-700 sketchy-card p-4 flex flex-col justify-between shadow-lg max-h-[380px] lg:max-h-none wobbly-glow">
          
          <div className="flex flex-col flex-1 min-h-0">
            <div className="text-sm font-bold uppercase tracking-wider text-yellow-300 border-b-2 border-dashed border-slate-800 pb-2 mb-3 font-display">
              🎯 LIVE GUESS CHAT
            </div>

            {/* Chat list viewport */}
            <div className="flex-1 overflow-y-auto space-y-2.5 pr-1 max-h-[200px] lg:max-h-[400px]">
              {messages.map(msg => (
                <div 
                  key={msg.id} 
                  className={`text-xs p-2 rounded-2xl border-2 ${
                    msg.type === 'correct' 
                      ? 'bg-emerald-500/10 border-emerald-500/80 text-emerald-300 font-bold shadow-[2px_2px_0px_0px_rgba(16,185,129,0.3)] font-display text-[13px]' 
                      : msg.type === 'close'
                        ? 'bg-amber-500/10 border-amber-500/80 text-amber-300 font-bold shadow-[2px_2px_0px_0px_rgba(245,158,11,0.3)] font-display text-[13px]'
                        : msg.type === 'system'
                          ? 'bg-indigo-950/60 border-indigo-900/40 text-indigo-300 font-display'
                          : 'bg-slate-950/60 border-slate-850 text-slate-350'
                  }`}
                >
                  {/* Speaker name */}
                  {msg.senderName && (
                    <span className="font-bold text-slate-100 block mb-0.5 font-display text-[13px]">
                      {msg.senderName}:
                    </span>
                  )}
                  <span className="font-sans text-slate-300">{msg.text}</span>
                </div>
              ))}
              <div ref={chatBottomRef} />
            </div>
          </div>

          {/* Typing Form console with sketching border */}
          <form onSubmit={handleSendMessage} className="mt-4 flex gap-1.5 pt-3 border-t-2 border-dashed border-slate-850 select-none">
            <input
              type="text"
              placeholder={
                currentDrawer?.id === 'user_player'
                  ? "You are drawing..." 
                  : userHasGuessedCorrectly 
                    ? "Guessed correctly!" 
                    : "Type keyword guess..."
              }
              value={chatInput}
              disabled={userHasGuessedCorrectly || currentDrawer?.id === 'user_player' || gameStatus === 'round_end' || gameStatus === 'game_over'}
              onChange={e => setChatInput(e.target.value)}
              className="flex-1 bg-slate-950/80 border-2 border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 placeholder-slate-655 disabled:opacity-40"
            />
            <button
              type="submit"
              disabled={userHasGuessedCorrectly || currentDrawer?.id === 'user_player' || gameStatus === 'round_end' || gameStatus === 'game_over'}
              className="p-3 bg-indigo-650 hover:bg-indigo-600 disabled:opacity-40 rounded-xl text-white transition cursor-pointer sketchy-btn border-indigo-400"
            >
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>

        </div>

      </div>

    </div>
  );
};
