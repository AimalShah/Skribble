import React, { useState } from 'react';
import { LeaderboardEntry } from '../types';
import { getFakeLeaderboard } from '../data/words';
import { AvatarSVG } from './AvatarCustomizer';
import { Trophy, Medal, Search, Flame, Target, Star } from 'lucide-react';

interface LeaderboardProps {
  currentStreak?: number;
  currentHighScore?: number;
}

export const Leaderboard: React.FC<LeaderboardProps> = ({ currentStreak = 3, currentHighScore = 1250 }) => {
  const [activeTab, setActiveTab] = useState<'daily' | 'weekly' | 'all-time'>('weekly');
  const [searchQuery, setSearchQuery] = useState<string>('');
  
  const entries = getFakeLeaderboard().filter(entry => entry.category === activeTab);
  
  // Filter by query
  const filteredEntries = entries.filter(entry => 
    entry.name.toLowerCase().includes(searchQuery.toLowerCase())
  ).sort((a,b) => b.score - a.score);

  // Divide into Podium (top 3) and remaining rows
  const podium = filteredEntries.slice(0, 3);
  const reorderPodium = () => {
    // Return order: [Silver (2), Gold (1), Bronze (3)] to match visual layouts
    const ordered = [];
    if (podium[1]) ordered.push(podium[1]); // Silver
    if (podium[0]) ordered.push(podium[0]); // Gold
    if (podium[2]) ordered.push(podium[2]); // Bronze
    return ordered;
  };
  
  const remainingRows = filteredEntries.slice(3);

  const getRankBadgeStyle = (rank: number) => {
    switch (rank) {
      case 1:
        return { 
          bg: 'bg-gradient-to-b from-amber-300 via-yellow-400 to-amber-500 text-yellow-950 border-amber-300 ring-amber-400/30',
          title: 'Champion', 
          icon: <Trophy className="w-5 h-5 text-yellow-950 fill-yellow-900/30" />
        };
      case 2:
        return { 
          bg: 'bg-gradient-to-b from-slate-200 via-gray-300 to-slate-400 text-slate-900 border-slate-200 ring-slate-300/30',
          title: 'Challenger',
          icon: <Medal className="w-5 h-5 text-slate-800" />
        };
      case 3:
        return { 
          bg: 'bg-gradient-to-b from-amber-600 via-amber-700 to-amber-800 text-amber-50 border-amber-600 ring-amber-700/30',
          title: 'Specialist',
          icon: <Medal className="w-5 h-5 text-amber-100" />
        };
      default:
        return null;
    }
  };

  return (
    <div className="bg-slate-900/80 sketchy-card border-slate-700 wobbly-glow-red p-6 max-w-4xl mx-auto w-full">
      
      {/* Title Header with achievements */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-yellow-300 flex items-center gap-2 font-display">
            <Trophy className="w-8 h-8 text-yellow-400 fill-yellow-400/20" />
            GLOBAL ARENA HALL OF FAME 🏆
          </h2>
          <p className="text-slate-300 text-sm mt-1">
            Top creative sketchers and quick guessers tracked in scribble real-time.
          </p>
        </div>

        {/* Personalized Stats Card badge */}
        <div className="flex items-center gap-4 bg-slate-950/80 p-3.5 border-2 border-dashed border-slate-700 rounded-2xl">
          <div className="flex items-center gap-1.5 text-orange-400 text-xs font-bold font-mono">
            <Flame className="w-4 h-4 fill-orange-500/25 text-orange-500 animate-pulse" />
            <div>
              <div className="text-slate-400 text-[10px] uppercase font-sans font-bold">STREAK</div>
              <div className="font-display text-sm">{currentStreak} Rounds</div>
            </div>
          </div>
          <div className="h-6 w-px bg-slate-800" />
          <div className="flex items-center gap-1.5 text-indigo-400 text-xs font-bold font-mono">
            <Target className="w-4 h-4 text-indigo-400" />
            <div>
              <div className="text-slate-400 text-[10px] uppercase font-sans font-bold">HIGH SCORE</div>
              <div className="font-display text-sm">{currentHighScore} pts</div>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs list & Search bar */}
      <div className="flex flex-col sm:flex-row justify-between items-center gap-4 mb-6">
        <div className="flex bg-slate-950/90 p-1.5 rounded-xl border-2 border-slate-800 w-full sm:w-auto">
          {(['daily', 'weekly', 'all-time'] as const).map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`flex-1 sm:flex-none uppercase px-5 py-2 rounded-lg text-xs font-bold tracking-wider transition-all duration-300 cursor-pointer ${
                activeTab === tab 
                  ? 'bg-indigo-600 text-white sketchy-btn border-indigo-400 shadow-md' 
                  : 'text-slate-400 hover:text-slate-100'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Search */}
        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 transform -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search artist name..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950/70 border-2 border-slate-850 rounded-xl py-2 pl-10 pr-4 text-sm text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500"
          />
        </div>
      </div>

      {/* Podium Layout for top 3 */}
      {filteredEntries.length > 0 && searchQuery === '' && (
        <div className="grid grid-cols-3 gap-3 md:gap-6 items-end justify-center mb-8 pt-4 border-b-2 border-dashed border-slate-700 pb-8">
          {reorderPodium().map(entry => {
            const isGold = entry.rank === 1;
            const badge = getRankBadgeStyle(entry.rank);

            return (
              <div 
                key={entry.name}
                className={`flex flex-col items-center select-none text-center transform hover:scale-105 transition-transform ${
                  isGold ? 'relative -top-2' : ''
                }`}
              >
                {/* Crown / Avatar */}
                <div className="relative mb-2">
                  <div className={`p-1.5 rounded-3xl border-3 ${
                    isGold ? 'border-yellow-400 wobbly-glow-red' : 'border-slate-700 wobbly-glow'
                  } bg-slate-950 shadow-xl`}>
                    <AvatarSVG config={entry.avatar} size={isGold ? 84 : 70} className="w-16 h-16 md:w-20 md:h-20" />
                  </div>
                  {/* Floating Rank Badge */}
                  <div className={`absolute -bottom-1.5 left-1/2 transform -translate-x-1/2 text-[10px] font-black px-3 py-0.5 rounded-full border shadow-md font-mono ${badge?.bg}`}>
                    {entry.rank === 1 ? 'GOLD' : entry.rank === 2 ? 'SILVER' : 'BRONZE'}
                  </div>
                </div>

                {/* Nickname */}
                <div className="mt-1">
                  <div className="flex items-center gap-1 justify-center">
                    <span className="text-sm md:text-md font-extrabold text-white truncate max-w-[80px] md:max-w-none font-display">
                      {entry.name}
                    </span>
                    {isGold && <Star className="w-3.5 h-3.5 text-yellow-400 fill-yellow-400/30 animate-pulse" />}
                  </div>
                  <div className="text-yellow-300 text-[10px] md:text-sm font-bold font-display">
                    {entry.score.toLocaleString()} pts
                  </div>
                </div>

                {/* Simulated Wins summary */}
                <div className="text-[10px] text-indigo-400 font-mono mt-1 opacity-95 hidden sm:block">
                  {entry.wins} wins • {entry.gamesPlayed} games
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Leaderboard Table Rows */}
      {filteredEntries.length > 0 ? (
        <div className="space-y-3 max-h-[300px] overflow-y-auto pr-1">
          {(searchQuery !== '' ? filteredEntries : remainingRows).map(entry => (
            <div 
              key={entry.name}
              className="flex items-center justify-between p-3.5 bg-slate-900/60 hover:bg-slate-950/70 border-2 border-slate-800/60 rounded-xl transition-all duration-200"
            >
              {/* Left group */}
              <div className="flex items-center gap-4">
                {/* Ranking spot */}
                <div className="w-8 flex justify-center text-sm font-bold text-slate-400 font-display">
                  #{entry.rank}
                </div>

                {/* Profile Avatar */}
                <div className="p-0.5 rounded-xl border-2 border-slate-700 bg-slate-950">
                  <AvatarSVG config={entry.avatar} size={36} className="w-9 h-9" />
                </div>

                {/* Nickname */}
                <div>
                  <div className="text-md font-bold text-slate-100 flex items-center gap-2 font-display">
                    {entry.name}
                  </div>
                  <div className="text-xs text-slate-400">
                    {entry.wins} tournament wins / {entry.gamesPlayed} practice rounds
                  </div>
                </div>
              </div>

              {/* Score output */}
              <div className="text-right">
                <span className="text-base font-bold text-yellow-300 font-display block">
                  {entry.score.toLocaleString()}
                </span>
                <span className="text-[10px] text-slate-400 block uppercase font-bold">points</span>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="py-12 text-center text-slate-400 border-2 border-dashed border-slate-800 rounded-2xl font-display text-lg">
          No artists matching "{searchQuery}"
        </div>
      )}
    </div>
  );
};
