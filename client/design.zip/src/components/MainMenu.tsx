import React, { useState, useEffect } from 'react';
import { AvatarConfig, LeaderboardEntry } from '../types';
import { generateRandomAvatar, AvatarCustomizer, AvatarSVG } from './AvatarCustomizer';
import { Trophy, Users, Shield, Zap, BookOpen, UserCheck, Star, Sparkles, LogOut, Code, Play } from 'lucide-react';
import { Leaderboard } from './Leaderboard';

interface MainMenuProps {
  onStartGame: (playerName: string, avatarConfig: AvatarConfig, isPracticeMode: boolean) => void;
}

export const MainMenu: React.FC<MainMenuProps> = ({ onStartGame }) => {
  // Auth states
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(false);
  const [userEmail, setUserEmail] = useState<string>('');
  const [userName, setUserName] = useState<string>('');
  const [avatar, setAvatar] = useState<AvatarConfig>(generateRandomAvatar());
  const [authEmailInput, setAuthEmailInput] = useState<string>('');
  const [authPasswordInput, setAuthPasswordInput] = useState<string>('');
  const [authNameInput, setAuthNameInput] = useState<string>('');
  const [isSignUp, setIsSignUp] = useState<boolean>(true);
  const [authMessage, setAuthMessage] = useState<string>('');
  const [isLobbySearching, setIsLobbySearching] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'play' | 'leaderboard' | 'about'>('play');

  // Load profile from localStorage on boot
  useEffect(() => {
    const savedEmail = localStorage.getItem('scribble_user_email');
    const savedName = localStorage.getItem('scribble_user_name');
    const savedAvatar = localStorage.getItem('scribble_user_avatar');

    if (savedEmail && savedName) {
      setUserEmail(savedEmail);
      setUserName(savedName);
      setIsLoggedIn(true);
      if (savedAvatar) {
        try {
          setAvatar(JSON.parse(savedAvatar));
        } catch {
          // Fallback
        }
      }
    } else {
      // Create random guest profile
      const guestNum = Math.floor(1000 + Math.random() * 9000);
      setUserName(`Painter_${guestNum}`);
    }
  }, []);

  const handleSimulatedAuth = (e: React.FormEvent) => {
    e.preventDefault();
    if (isSignUp) {
      if (!authNameInput.trim() || !authEmailInput.trim() || !authPasswordInput.trim()) {
        setAuthMessage('Please fill in all signup details.');
        return;
      }
      // Save details to simulated localStorage
      localStorage.setItem('scribble_user_email', authEmailInput);
      localStorage.setItem('scribble_user_name', authNameInput);
      localStorage.setItem('scribble_user_avatar', JSON.stringify(avatar));
      
      setUserEmail(authEmailInput);
      setUserName(authNameInput);
      setIsLoggedIn(true);
      setAuthMessage('Account registered successfully!');
    } else {
      if (!authEmailInput.trim() || !authPasswordInput.trim()) {
        setAuthMessage('Please complete login fields.');
        return;
      }
      // Log in
      localStorage.setItem('scribble_user_email', authEmailInput);
      const splitName = authEmailInput.split('@')[0];
      const fallbackName = splitName.charAt(0).toUpperCase() + splitName.slice(1);
      localStorage.setItem('scribble_user_name', fallbackName);
      localStorage.setItem('scribble_user_avatar', JSON.stringify(avatar));

      setUserEmail(authEmailInput);
      setUserName(fallbackName);
      setIsLoggedIn(true);
      setAuthMessage('Welcome back, artist!');
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('scribble_user_email');
    localStorage.removeItem('scribble_user_name');
    localStorage.removeItem('scribble_user_avatar');
    setIsLoggedIn(false);
    setUserEmail('');
    const guestNum = Math.floor(1000 + Math.random() * 9000);
    setUserName(`Painter_${guestNum}`);
    setAuthMessage('Logged out successfully.');
  };

  // Launch matchmaking animation
  const handleToggleMatchmaking = (isPractice: boolean = false) => {
    if (isPractice) {
      onStartGame(userName, avatar, true);
      return;
    }

    setIsLobbySearching(true);
    // Dynamic matchmaking feel! Waiting for players to join lobby...
    const timer = setTimeout(() => {
      setIsLobbySearching(false);
      onStartGame(userName, avatar, false);
    }, 2200);

    return () => clearTimeout(timer);
  };

  return (
    <div className="max-w-5xl mx-auto w-full px-4 py-8">
      
      {/* Dynamic Splash Brand Banner */}
      <div className="text-center mb-10 select-none animate-fadeIn">
        <div className="inline-flex items-center gap-2 px-3 py-1 bg-indigo-500/15 text-indigo-300 border-2 border-dashed border-indigo-400/40 rounded-full text-xs font-semibold uppercase tracking-wider mb-4">
          <Sparkles className="w-3.5 h-3.5 animate-bounce" />
          <span>Hand-Drawn Multiplayer Ink Arena v2.5</span>
        </div>
        <h1 className="text-5xl md:text-7xl font-bold tracking-tight text-yellow-300 drop-shadow-md font-display transform -rotate-1 inline-block">
          🖍️ SKRIBBLE <span className="text-pink-400">STUDIO</span> 🎨
        </h1>
        <p className="text-slate-300 text-base mt-3 max-w-xl mx-auto font-sans leading-relaxed">
          Scribble, sketch, guess, and laugh! Play with friendly automated bots or test your styling. Draw vector sweeps in sketchy pixel layouts.
        </p>
      </div>

      {/* Navigation Rails tabs with doodly outline */}
      <div className="flex border-3 border-slate-700/80 mb-8 max-w-lg mx-auto bg-slate-900/80 p-2 rounded-2xl sketchy-card-subtle wobbly-glow">
        <button
          onClick={() => setActiveTab('play')}
          className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-sm font-bold tracking-wide transition-all duration-300 cursor-pointer ${
            activeTab === 'play' ? 'bg-indigo-600 text-white sketchy-btn border-indigo-400 wobbly-glow' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Play className="w-4 h-4 fill-current" />
          Ink Dojo
        </button>
        <button
          onClick={() => setActiveTab('leaderboard')}
          className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-sm font-bold tracking-wide transition-all duration-300 cursor-pointer ${
            activeTab === 'leaderboard' ? 'bg-indigo-600 text-white sketchy-btn border-indigo-400 wobbly-glow' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Trophy className="w-4 h-4" />
          Rankings
        </button>
        <button
          onClick={() => setActiveTab('about')}
          className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-sm font-bold tracking-wide transition-all duration-300 cursor-pointer ${
            activeTab === 'about' ? 'bg-indigo-600 text-white sketchy-btn border-indigo-400 wobbly-glow' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <BookOpen className="w-4 h-4" />
          Game Rules
        </button>
      </div>

      {/* Content Columns depending on active view */}
      {activeTab === 'play' && (
        <div className="grid lg:grid-cols-12 gap-8 items-start">
          
          {/* LEFT PANEL: AUTH & PROFILE GENERATOR (Lg Span 5) */}
          <div className="lg:col-span-5 bg-slate-900/80 sketchy-card border-slate-700/90 wobbly-glow p-6 space-y-6">
            
            {/* profile summary if logged in */}
            {isLoggedIn ? (
              <div className="bg-slate-950/80 p-5 rounded-2xl border-2 border-dashed border-slate-700 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="p-0.5 bg-indigo-500 rounded-2xl border-2 border-indigo-400 shadow-md">
                    <AvatarSVG config={avatar} size={54} className="w-14 h-14" />
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="font-extrabold text-white text-md tracking-wide">{userName}</span>
                      <Shield className="w-3.5 h-3.5 text-indigo-400" />
                    </div>
                    <span className="text-xs text-slate-400 truncate block max-w-[150px]">{userEmail}</span>
                  </div>
                </div>

                <button
                  onClick={handleLogout}
                  title="Logout Profile"
                  className="p-2.5 text-slate-500 hover:text-red-400 hover:bg-red-500/10 rounded-xl transition duration-250 cursor-pointer"
                >
                  <LogOut className="w-4.5 h-4.5" />
                </button>
              </div>
            ) : (
              /* Custom Authentic Authentication Form Card */
              <div className="space-y-4">
                <div className="flex justify-between items-center bg-slate-950/50 p-2 rounded-xl border border-slate-800">
                  <h3 className="text-md font-bold text-slate-200 flex items-center gap-1.5 font-display">
                    <Shield className="w-4 h-4 text-indigo-400" />
                    {isSignUp ? 'REGISTER AN ACCOUNT' : 'LOG IN TO SYNC'}
                  </h3>
                  <button
                    onClick={() => {
                      setIsSignUp(!isSignUp);
                      setAuthMessage('');
                    }}
                    className="text-xs font-bold text-yellow-400 hover:underline"
                  >
                    {isSignUp ? 'Have account?' : 'Need signup?'}
                  </button>
                </div>

                <form onSubmit={handleSimulatedAuth} className="space-y-3">
                  {isSignUp && (
                    <input
                      type="text"
                      placeholder="Input Artist Nickname..."
                      required
                      value={authNameInput}
                      onChange={e => {
                        setAuthNameInput(e.target.value);
                        setUserName(e.target.value);
                      }}
                      className="w-full bg-slate-950/80 text-sm border-2 border-slate-800 rounded-xl px-4 py-2.5 text-slate-200 focus:outline-none focus:border-indigo-500 placeholder-slate-600 font-sans"
                    />
                  )}
                  <input
                    type="email"
                    placeholder="Enter Email Address..."
                    required
                    value={authEmailInput}
                    onChange={e => setAuthEmailInput(e.target.value)}
                    className="w-full bg-slate-950/80 text-sm border-2 border-slate-800 rounded-xl px-4 py-2.5 text-slate-200 focus:outline-none focus:border-indigo-500 placeholder-slate-600 font-sans"
                  />
                  <input
                    type="password"
                    placeholder="Set Login Password..."
                    required
                    value={authPasswordInput}
                    onChange={e => setAuthPasswordInput(e.target.value)}
                    className="w-full bg-slate-950/80 text-sm border-2 border-slate-800 rounded-xl px-4 py-2.5 text-slate-200 focus:outline-none focus:border-indigo-500 placeholder-slate-600 font-sans"
                  />
                  <button
                    type="submit"
                    className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-sm tracking-wide py-3 sketchy-btn border-white/20 hover:border-white shadow flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <UserCheck className="w-4 h-4" />
                    {isSignUp ? 'Create Scribble Profile' : 'Access Account'}
                  </button>
                </form>

                {authMessage && (
                  <p className="text-center text-xs text-orange-400 bg-orange-950/20 py-2 border border-orange-900/30 rounded-lg">
                    {authMessage}
                  </p>
                )}
              </div>
            )}

            {/* General Nickname state display (for quickly custom nicks) */}
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-wide text-slate-400 block font-display">Dojo Name (Fallback)</label>
              <input
                type="text"
                placeholder="Ex. PencilKing"
                value={userName}
                onChange={e => setUserName(e.target.value)}
                maxLength={18}
                className="w-full bg-slate-950/80 border-2 border-slate-800 px-4 py-3 rounded-xl text-md font-extrabold text-white tracking-wide focus:outline-none focus:border-indigo-500 font-sans"
              />
            </div>

            {/* Quick Matchmaking and Practice Mode Actions */}
            <div className="space-y-3 pt-2">
              <button
                disabled={isLobbySearching}
                onClick={() => handleToggleMatchmaking(false)}
                className="w-full bg-indigo-500 hover:bg-indigo-600 text-white font-extrabold text-md py-4 sketchy-btn border-yellow-300 wobbly-glow flex items-center justify-center gap-2 cursor-pointer"
              >
                {isLobbySearching ? (
                  <>
                    <Users className="w-4 h-4 text-white animate-spin" />
                    <span>Searching for painters (Join 4/8)...</span>
                  </>
                ) : (
                  <>
                    <Users className="w-5 h-5 text-indigo-100 fill-indigo-200/20" />
                    <span>🚀 MATCHMAKING QUICK-PLAY</span>
                  </>
                )}
              </button>

              <button
                onClick={() => handleToggleMatchmaking(true)}
                className="w-full bg-yellow-400 text-slate-950 hover:bg-yellow-300 hover:scale-103 font-bold py-3.5 sketchy-btn border-slate-950 text-sm tracking-wide transition flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Code className="w-4 h-4" />
                ✏️ SOLO PRACTICE DOJO
              </button>
            </div>
            
          </div>

          {/* RIGHT PANEL: CHERISHED AVATAR CUSTOMIZER (Lg Span 7) */}
          <div className="lg:col-span-7 flex flex-col gap-4">
            <div className="bg-slate-900/80 p-2 sketchy-card border-slate-700 wobbly-glow-red">
              <AvatarCustomizer config={avatar} onChange={setAvatar} />
            </div>
            
            {/* Extra achievements mini card */}
            <div className="bg-slate-900/80 border-3 border-slate-700 sketchy-card wobbly-glow p-6 grid grid-cols-3 gap-4 text-center">
              <div>
                <span className="text-2xl font-bold font-mono text-amber-400 block font-display">15</span>
                <span className="text-xs text-slate-400 uppercase tracking-wide">Drawn</span>
              </div>
              <div className="border-x border-slate-800">
                <span className="text-2xl font-bold font-mono text-purple-400 block font-display">45</span>
                <span className="text-xs text-slate-400 uppercase tracking-wide">Guessed</span>
              </div>
              <div>
                <span className="text-2xl font-bold font-mono text-indigo-400 block font-display">Grade A</span>
                <span className="text-xs text-slate-400 uppercase tracking-wide">Studio ranking</span>
              </div>
            </div>
          </div>

        </div>
      )}

      {activeTab === 'leaderboard' && (
        <div className="animate-fadeIn">
          <Leaderboard />
        </div>
      )}

      {activeTab === 'about' && (
        <div className="max-w-3xl mx-auto space-y-6 bg-slate-900/80 border-3 border-slate-700 sketchy-card p-8 text-slate-300 wobbly-glow">
          <h2 className="text-3xl font-bold text-white flex items-center gap-2 mb-2 font-display">
            <BookOpen className="w-7 h-7 text-yellow-400" />
            HOW TO PLAY SKRIBBLE STUDIO
          </h2>
          
          <div className="space-y-4">
            <div className="flex gap-3">
              <div className="w-7 h-7 rounded-full bg-indigo-600/20 border-2 border-indigo-400 text-indigo-400 text-sm font-black flex items-center justify-center shrink-0">1</div>
              <div>
                <p className="font-extrabold text-slate-200 text-base font-display">The Core Flow</p>
                <p className="text-slate-400 text-sm">Each round, one artist is elected to draw the secret word. All other players try to analyze the wobbly canvas and type guesses as quickly as possible!</p>
              </div>
            </div>

            <div className="flex gap-3">
              <div className="w-7 h-7 rounded-full bg-indigo-600/20 border-2 border-indigo-400 text-indigo-400 text-sm font-black flex items-center justify-center shrink-0">2</div>
              <div>
                <p className="font-extrabold text-slate-200 text-base font-display">The Timer Clock</p>
                <p className="text-slate-400 text-sm">You have 60 seconds per round. The faster you guess the word, the more speed-bonus points you receive. The drawer also earns points based on how many players guess correctly!</p>
              </div>
            </div>

            <div className="flex gap-3">
              <div className="w-7 h-7 rounded-full bg-indigo-600/20 border-2 border-indigo-400 text-indigo-400 text-sm font-black flex items-center justify-center shrink-0">3</div>
              <div>
                <p className="font-extrabold text-slate-200 text-base font-display">Drawing Toolbar</p>
                <p className="text-slate-400 text-sm">Artists get an extensive dashboard: a 24-color professional color swatch, brush-radius sliders, erasers, flood-bucket fill tools, undo history, and a full-erase bin.</p>
              </div>
            </div>

            <div className="flex gap-3">
              <div className="w-7 h-7 rounded-full bg-indigo-600/20 border-2 border-indigo-400 text-indigo-400 text-sm font-black flex items-center justify-center shrink-0">4</div>
              <div>
                <p className="font-extrabold text-slate-200 text-base font-display">Simulated Multi-Interaction Experience</p>
                <p className="text-slate-400 text-sm">Offline yet extremely interactive! Active bots write random close-guesses, correct-guesses, cheer, mock their own draws, and sketch genuine vector path assets. Practice your drawing inside the Drawing Dojo any time.</p>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
