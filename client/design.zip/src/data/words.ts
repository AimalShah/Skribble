import { WordItem, DrawingStroke, LeaderboardEntry } from '../types';

export const GAME_WORDS: WordItem[] = [
  {
    word: 'Sun',
    category: 'Nature ☀️',
    hint: 'Basking in the daytime sky, giving warmth',
    botPath: [
      // Main boundary circle (approximation)
      'circle:200:150:40:stroke',
      // Sun rays
      'line:200:90:200:60',
      'line:200:210:200:240',
      'line:140:150:110:150',
      'line:260:150:290:150',
      'line:158:108:136:86',
      'line:242:192:264:214',
      'line:158:192:136:214',
      'line:242:108:264:86'
    ]
  },
  {
    word: 'House',
    category: 'Architecture 🏠',
    hint: 'A sanctuary with a roof, a door, and walls',
    botPath: [
      // Main body box
      'rect:120:140:160:110',
      // Roof triangle
      'line:120:140:200:70',
      'line:200:70:280:140',
      // Door
      'rect:185:200:30:50',
      // Door knob
      'circle:210:225:3:fill',
      // Window left
      'rect:140:160:30:30',
      'line:155:160:155:190',
      'line:140:175:170:175',
      // Window right
      'rect:230:160:30:30',
      // Chimney
      'line:250:113:250:80',
      'line:250:80:265:80',
      'line:265:80:265:126'
    ]
  },
  {
    word: 'Tree',
    category: 'Nature 🌲',
    hint: 'Has bark, branches, and countless green leaves',
    botPath: [
      // Trunk
      'rect:185:190:30:75',
      // Trunk texture Lines
      'line:195:200:195:240',
      'line:205:210:205:250',
      // Leaf outlines (layered circles/clouds)
      'circle:200:130:50:fill_green',
      'circle:160:150:40:fill_green',
      'circle:240:150:40:fill_green',
      'circle:200:90:35:fill_green'
    ]
  },
  {
    word: 'Car',
    category: 'Transportation 🚗',
    hint: 'Needs fuel, has four wheels, and a windshield',
    botPath: [
      // Car body (bottom)
      'rect:100:160:200:50',
      // Cabin (top)
      'line:130:160:160:110',
      'line:160:110:240:110',
      'line:240:110:270:160',
      // Left Wheel
      'circle:140:210:20:stroke',
      'circle:140:210:8:fill',
      // Right wheel
      'circle:260:210:20:stroke',
      'circle:260:210:8:fill',
      // Window separator
      'line:195:110:195:160',
      // Headlight
      'circle:100:175:5:fill_yellow'
    ]
  },
  {
    word: 'Cloud',
    category: 'Nature ☁️',
    hint: 'Floating water droplets reflecting sunlight in the sky',
    botPath: [
      'circle:160:160:30:stroke',
      'circle:200:140:40:stroke',
      'circle:248:150:35:stroke',
      'circle:214:180:30:stroke',
      'circle:165:180:25:stroke',
      // Connecting bottom line
      'line:140:185:270:185'
    ]
  },
  {
    word: 'Apple',
    category: 'Food 🍎',
    hint: 'Sweet round red fruit, favorite of teachers and gravity',
    botPath: [
      // Body (bilobed apple shape)
      'circle:180:160:35:stroke_red',
      'circle:220:160:35:stroke_red',
      // Bottom crease indent
      'line:190:194:210:194',
      // Branch stem
      'line:200:130:200:100',
      // Leaf
      'line:200:110:225:95',
      'line:225:95:215:108',
      'line:215:108:200:110'
    ]
  },
  {
    word: 'Cup',
    category: 'Kitchen ☕',
    hint: 'Holds your warm morning coffee, tea, or cocoa',
    botPath: [
      // Main cup base cylindrical shape
      'rect:140:120:120:100',
      // Rim top oval
      'line:140:120:260:120',
      // Cup handle
      'line:260:140:290:150',
      'line:290:150:290:190',
      'line:290:190:260:200',
      // Hot steam curves
      'line:170:105:175:85',
      'line:200:105:205:85',
      'line:230:105:235:85'
    ]
  },
  {
    word: 'Boat',
    category: 'Transportation ⛵',
    hint: 'Sails across the deep blue waves with wind',
    botPath: [
      // Hull
      'line:110:180:290:180',
      'line:290:180:250:220',
      'line:250:220:150:220',
      'line:150:220:110:180',
      // Mast
      'line:200:180:200:80',
      // Triangular Sail
      'line:200:90:140:160',
      'line:140:160:200:160',
      // Waves underneath
      'line:90:230:130:230',
      'line:160:230:200:230',
      'line:230:230:270:230'
    ]
  },
  {
    word: 'Pizza',
    category: 'Food 🍕',
    hint: 'Triangular slice overflowing with cheese and toppings',
    botPath: [
      // Slice outline (Triangle)
      'line:150:110:250:110',
      'line:250:110:200:230',
      'line:200:230:150:110',
      // Crust
      'rect:145:102:110:8',
      // Pepperonis
      'circle:180:130:6:fill_red',
      'circle:220:140:6:fill_red',
      'circle:200:175:6:fill_red',
      // Cheese lines
      'line:170:120:175:125',
      'line:230:120:225:128'
    ]
  },
  {
    word: 'Snowman',
    category: 'Holiday ⛄',
    hint: 'Formed from rolled snow spheres, sporting a carrot nose',
    botPath: [
      // Bottom sphere
      'circle:200:210:40:stroke',
      // Middle sphere
      'circle:200:145:30:stroke',
      // Top Head circle
      'circle:200:100:20:stroke',
      // Coal eyes
      'circle:193:97:2:fill',
      'circle:207:97:2:fill',
      // Carrot nose (triangle outline)
      'line:200:100:215:102',
      'line:215:102:200:105',
      // Coal buttons
      'circle:200:135:3:fill',
      'circle:200:150:3:fill',
      'circle:200:165:3:fill',
      // Stick arm left
      'line:170:145:130:130',
      'line:140:137:135:125',
      // Stick arm right
      'line:230:145:270:130'
    ]
  },
  {
    word: 'Sword',
    category: 'Weapon ⚔️',
    hint: 'A polished metal blade wielded by knights',
    botPath: [
      // Blade lines
      'line:150:230:230:150',
      'line:158:222:238:142',
      // Blade tip
      'line:230:150:242:138',
      'line:238:142:242:138',
      // Hilt center guard
      'line:140:210:170:240',
      // Grip handle
      'rect:120:240:24:24',
      // Pommel cap
      'circle:122:262:4:fill'
    ]
  },
  {
    word: 'Star',
    category: 'Space ⭐',
    hint: 'A bright stellar spot of light seen at night',
    botPath: [
      // Classic 5 point star connected coordinates
      'line:200:70:225:125',
      'line:225:125:285:130',
      'line:285:130:235:170',
      'line:235:170:255:225',
      'line:255:225:200:190',
      'line:200:190:145:225',
      'line:145:225:165:170',
      'line:165:170:115:130',
      'line:115:130:175:125',
      'line:175:125:200:70'
    ]
  }
];

export const getRandomWord = (): WordItem => {
  const index = Math.floor(Math.random() * GAME_WORDS.length);
  return GAME_WORDS[index];
};

export const getFakeLeaderboard = (): LeaderboardEntry[] => {
  return [
    { rank: 1, name: 'ScribbleWiz', avatar: { bgColor: '#818CF8', eyes: 4, mouth: 0, face: 1, accessory: 4 }, score: 18450, gamesPlayed: 245, wins: 112, category: 'all-time' },
    { rank: 2, name: 'DoodleBob', avatar: { bgColor: '#FBBF24', eyes: 2, mouth: 4, face: 4, accessory: 3 }, score: 16210, gamesPlayed: 210, wins: 89, category: 'all-time' },
    { rank: 3, name: 'SketchMaster', avatar: { bgColor: '#34D399', eyes: 1, mouth: 1, face: 2, accessory: 1 }, score: 15150, gamesPlayed: 198, wins: 76, category: 'all-time' },
    { rank: 4, name: 'PicassoBot', avatar: { bgColor: '#F472B6', eyes: 3, mouth: 3, face: 3, accessory: 2 }, score: 13990, gamesPlayed: 180, wins: 64, category: 'all-time' },
    { rank: 5, name: 'DrawOrDie', avatar: { bgColor: '#F87171', eyes: 5, mouth: 5, face: 0, accessory: 3 }, score: 12500, gamesPlayed: 165, wins: 55, category: 'all-time' },
    
    // Weekly
    { rank: 1, name: 'DoodleBob', avatar: { bgColor: '#FBBF24', eyes: 2, mouth: 4, face: 4, accessory: 3 }, score: 2850, gamesPlayed: 32, wins: 14, category: 'weekly' },
    { rank: 2, name: 'PixelArt', avatar: { bgColor: '#06B6D4', eyes: 0, mouth: 0, face: 5, accessory: 0 }, score: 2400, gamesPlayed: 28, wins: 11, category: 'weekly' },
    { rank: 3, name: 'Lines&Curves', avatar: { bgColor: '#818CF8', eyes: 4, mouth: 1, face: 1, accessory: 2 }, score: 2190, gamesPlayed: 25, wins: 10, category: 'weekly' },
    { rank: 4, name: 'BrushQueen', avatar: { bgColor: '#A78BFA', eyes: 1, mouth: 2, face: 2, accessory: 4 }, score: 1980, gamesPlayed: 22, wins: 8, category: 'weekly' },
    { rank: 5, name: 'ScribbleWiz', avatar: { bgColor: '#818CF8', eyes: 4, mouth: 0, face: 1, accessory: 4 }, score: 1820, gamesPlayed: 20, wins: 7, category: 'weekly' },

    // Daily
    { rank: 1, name: 'PixelArt', avatar: { bgColor: '#06B6D4', eyes: 0, mouth: 0, face: 5, accessory: 0 }, score: 940, gamesPlayed: 9, wins: 4, category: 'daily' },
    { rank: 2, name: 'QuickDraw', avatar: { bgColor: '#FB923C', eyes: 1, mouth: 4, face: 0, accessory: 0 }, score: 810, gamesPlayed: 8, wins: 3, category: 'daily' },
    { rank: 3, name: 'ColorLover', fill_color: '#34D399', avatar: { bgColor: '#34D399', eyes: 4, mouth: 0, face: 3, accessory: 2 }, score: 750, gamesPlayed: 7, wins: 3, category: 'daily' },
    { rank: 4, name: 'WhatisThat', avatar: { bgColor: '#0F172A', eyes: 5, mouth: 3, face: 4, accessory: 1 }, score: 620, gamesPlayed: 8, wins: 2, category: 'daily' },
    { rank: 5, name: 'SketchyBiz', avatar: { bgColor: '#E2E8F0', eyes: 0, mouth: 5, face: 1, accessory: 0 }, score: 550, gamesPlayed: 6, wins: 1, category: 'daily' }
  ] as unknown as LeaderboardEntry[];
};

export const BOT_NAMES = [
  'WizDoodle', 'CanvasChaser', 'InkSpiller', 'PicassoKid', 'LinesLord', 
  'SketchyAI', 'BrushMata', 'PaintPal', 'ColorWitch', 'GrafittiGuru'
];
