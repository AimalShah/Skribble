export interface AvatarConfig {
  bgColor: string;
  eyes: number;
  mouth: number;
  face: number; // custom hairstyle/head accessories
  accessory: number; // glasses, hats, etc.
}

export interface Player {
  id: string;
  name: string;
  avatar: AvatarConfig;
  score: number;
  isDrawing: boolean;
  isHost: boolean;
  hasGuessed: boolean;
  rank?: number;
  isBot?: boolean;
}

export interface Message {
  id: string;
  senderId?: string; // empty means system
  senderName?: string;
  text: string;
  timestamp: string;
  type: 'chat' | 'system' | 'correct' | 'close'; 
}

export interface DrawingPoint {
  x: number;
  y: number;
}

export interface DrawingStroke {
  points: DrawingPoint[];
  color: string;
  lineWidth: number;
  mode: 'draw' | 'erase';
}

export interface WordItem {
  word: string;
  category: string;
  hint: string;
  botPath?: string[]; // predefined SVG paths for bot drawing
}

export interface LeaderboardEntry {
  rank: number;
  name: string;
  avatar: AvatarConfig;
  score: number;
  gamesPlayed: number;
  wins: number;
  category: string; // 'daily' | 'weekly' | 'all-time'
}

export type GameStatus = 'lobby' | 'selecting_word' | 'drawing' | 'round_end' | 'game_over';
